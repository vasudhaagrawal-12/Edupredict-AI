"""
Preprocessing Pipeline Module for EduPredict AI
Constructs reproducible, leakage-free sklearn ColumnTransformer pipelines.
"""

from typing import List, Tuple
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline

NUMERIC_FEATURES_EARLY = [
    "age", "traveltime", "studytime", "failures", "famrel", "freetime", 
    "goout", "Dalc", "Walc", "health", "absences", "alcohol_consumption_index", 
    "family_support_score"
]

NUMERIC_FEATURES_PERFORMANCE = NUMERIC_FEATURES_EARLY + [
    "G1", "G2", "assessment_trend"
]

CATEGORICAL_FEATURES = [
    "school", "sex", "address", "famsize", "Pstatus", "Mjob", "Fjob",
    "reason", "guardian", "schoolsup", "famsup", "paid", "activities",
    "nursery", "higher", "internet", "romantic"
]

def build_preprocessor(mode: str = "performance") -> ColumnTransformer:
    """
    Builds an un-fit ColumnTransformer preprocessor for numerical and categorical features.
    
    Args:
        mode: 'early_warning' or 'performance'
        
    Returns:
        ColumnTransformer instance.
    """
    numeric_cols = NUMERIC_FEATURES_EARLY if mode == "early_warning" else NUMERIC_FEATURES_PERFORMANCE
    
    num_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])
    
    cat_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("encoder", OneHotEncoder(handle_unknown="ignore", sparse_output=False))
    ])
    
    preprocessor = ColumnTransformer(
        transformers=[
            ("num", num_pipeline, numeric_cols),
            ("cat", cat_pipeline, CATEGORICAL_FEATURES)
        ],
        remainder="drop"
    )
    
    return preprocessor
