"""
Evaluation Metrics Helper for EduPredict AI
Computes real, un-fabricated regression and classification performance metrics.
"""

from typing import Dict, Any
import numpy as np
from sklearn.metrics import (
    mean_absolute_error, mean_squared_error, r2_score,
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, precision_recall_curve, auc, brier_score_loss,
    confusion_matrix
)

def evaluate_regression(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
    """Computes MAE, RMSE, and R2 regression metrics."""
    mae = float(round(mean_absolute_error(y_true, y_pred), 4))
    mse = float(mean_squared_error(y_true, y_pred))
    rmse = float(round(np.sqrt(mse), 4))
    r2 = float(round(r2_score(y_true, y_pred), 4))
    
    return {
        "mae": mae,
        "rmse": rmse,
        "r2": r2
    }

def evaluate_classification(y_true: np.ndarray, y_pred_labels: np.ndarray, y_pred_probs: np.ndarray) -> Dict[str, Any]:
    """Computes Accuracy, Precision, Recall, F1, ROC-AUC, PR-AUC, Brier score, and Confusion Matrix."""
    acc = float(round(accuracy_score(y_true, y_pred_labels), 4))
    prec = float(round(precision_score(y_true, y_pred_labels, zero_division=0), 4))
    rec = float(round(recall_score(y_true, y_pred_labels, zero_division=0), 4))
    f1 = float(round(f1_score(y_true, y_pred_labels, zero_division=0), 4))
    
    try:
        roc_auc = float(round(roc_auc_score(y_true, y_pred_probs), 4))
    except Exception:
        roc_auc = 0.5

    try:
        p_precision, p_recall, _ = precision_recall_curve(y_true, y_pred_probs)
        pr_auc = float(round(auc(p_recall, p_precision), 4))
    except Exception:
        pr_auc = 0.5

    brier = float(round(brier_score_loss(y_true, y_pred_probs), 4))
    cm = confusion_matrix(y_true, y_pred_labels).tolist()

    return {
        "accuracy": acc,
        "precision": prec,
        "recall": rec,
        "f1": f1,
        "roc_auc": roc_auc,
        "pr_auc": pr_auc,
        "brier_score": brier,
        "confusion_matrix": cm
    }
