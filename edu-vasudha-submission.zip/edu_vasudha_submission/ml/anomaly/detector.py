"""
Isolation Forest Anomaly Detection Module for EduPredict AI
Flags unusual student feature patterns relative to population reference distribution.
"""

from typing import Dict, Any
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest

class AnomalyDetector:
    def __init__(self, contamination: float = 0.05, random_state: int = 42):
        self.detector = IsolationForest(contamination=contamination, random_state=random_state)
        self.is_fitted = False

    def fit(self, X: pd.DataFrame):
        # Select numeric columns
        numeric_df = X.select_dtypes(include=[np.number])
        if not numeric_df.empty:
            self.detector.fit(numeric_df)
            self.is_fitted = True

    def predict_anomaly(self, input_df: pd.DataFrame) -> Dict[str, Any]:
        """
        Determines if an input student record represents an anomalous feature pattern.
        """
        numeric_df = input_df.select_dtypes(include=[np.number])
        if not self.is_fitted or numeric_df.empty:
            return {"is_anomaly": False, "anomaly_score": 0.0, "description": "Normal pattern (un-fitted fallback)"}

        # Predict (-1 is anomaly, 1 is normal)
        pred = self.detector.predict(numeric_df)[0]
        score = float(self.detector.score_samples(numeric_df)[0])
        
        is_anomaly = bool(pred == -1)

        description = (
            "Anomalous pattern detected: Student feature combination differs significantly from reference population data."
            if is_anomaly
            else "Normal pattern: Feature values match standard student population trends."
        )

        return {
            "is_anomaly": is_anomaly,
            "anomaly_score": round(score, 4),
            "description": description
        }
