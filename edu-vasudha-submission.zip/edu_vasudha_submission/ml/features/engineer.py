"""
Feature Engineering Module for EduPredict AI
Applies academically justified transformations without data leakage.
"""

import pandas as pd
import numpy as np

def engineer_features(df: pd.DataFrame, mode: str = "performance") -> pd.DataFrame:
    """
    Engineers derived features based on specified prediction mode.
    
    Args:
        df: Input DataFrame containing student features.
        mode: 'early_warning' (pre-assessment) or 'performance' (assessment-integrated).
        
    Returns:
        DataFrame with added engineered feature columns.
    """
    df = df.copy()

    # 1. Past Failures Flag (Mode A & B)
    if "failures" in df.columns:
        df["past_failures_flag"] = (df["failures"] > 0).astype(int)
    else:
        df["past_failures_flag"] = 0

    # 2. Alcohol Consumption Index (Mode A & B)
    if "Dalc" in df.columns and "Walc" in df.columns:
        df["alcohol_consumption_index"] = df["Dalc"] + df["Walc"]
    else:
        df["alcohol_consumption_index"] = 2

    # 3. Family Support Score (Mode A & B)
    medu = df["Medu"] if "Medu" in df.columns else 2
    fedu = df["Fedu"] if "Fedu" in df.columns else 2
    famrel = df["famrel"] if "famrel" in df.columns else 3
    df["family_support_score"] = ((medu + fedu) / 2.0) + (famrel / 5.0)

    # 4. Assessment Trend (Mode B Only)
    if mode == "performance" and "G1" in df.columns and "G2" in df.columns:
        df["assessment_trend"] = df["G2"] - df["G1"]
    elif mode == "early_warning":
        # Ensure G1/G2/assessment_trend are dropped or absent
        for col in ["G1", "G2", "assessment_trend"]:
            if col in df.columns:
                df = df.drop(columns=[col])

    return df
