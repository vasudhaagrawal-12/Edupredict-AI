"""
Reproducible ML Model Training & Evaluation Pipeline
Trains, tunes, calibrates, evaluates, and persists best models for EduPredict AI.
"""

import os
import json
import datetime
import joblib
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.calibration import CalibratedClassifierCV

# Regression Candidates (5)
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from xgboost import XGBRegressor

# Classification Candidates (4)
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from xgboost import XGBClassifier

from ml.features.engineer import engineer_features
from ml.preprocessing.pipeline import build_preprocessor
from ml.evaluation.metrics import evaluate_regression, evaluate_classification

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
RAW_DATA_PATH = os.path.join(REPO_ROOT, "data", "raw", "student-mat.csv")
ARTIFACTS_DIR = os.path.join(REPO_ROOT, "ml", "artifacts")

RANDOM_SEED = 42

def train_and_evaluate_all(mode: str = "performance"):
    """
    Trains 5 regression candidates and 4 classification candidates, evaluates on held-out test set,
    selects best models, and persists artifacts.
    """
    print(f"--- Starting ML Training Pipeline (Mode: {mode}) ---")
    
    if not os.path.exists(RAW_DATA_PATH):
        raise FileNotFoundError(f"Raw data file not found at {RAW_DATA_PATH}")

    try:
        df = pd.read_csv(RAW_DATA_PATH, sep=";")
        if len(df.columns) < 5:
            df = pd.read_csv(RAW_DATA_PATH, sep=",")
    except Exception as e:
        raise ValueError(f"Failed to read dataset: {e}")

    # Targets
    df["final_marks"] = df["G3"] * 5.0
    df["at_risk"] = (df["G3"] < 10).astype(int)

    # Apply Feature Engineering
    df_engineered = engineer_features(df, mode=mode)

    # Drop target columns from features
    X = df_engineered.drop(columns=["G3", "final_marks", "at_risk"], errors="ignore")
    y_reg = df_engineered["final_marks"]
    y_cls = df_engineered["at_risk"]

    # Stratified Train/Test split
    X_train, X_test, y_reg_train, y_reg_test, y_cls_train, y_cls_test = train_test_split(
        X, y_reg, y_cls, test_size=0.2, random_state=RANDOM_SEED, stratify=y_cls
    )

    print(f"Dataset split: {len(X_train)} train samples, {len(X_test)} test samples.")

    # -------------------------------------------------------------
    # 1. REGRESSION MODELS (5 Candidates)
    # -------------------------------------------------------------
    reg_candidates = {
        "Linear Regression": LinearRegression(),
        "Ridge Regression": Ridge(alpha=1.0, random_state=RANDOM_SEED),
        "Random Forest Regressor": RandomForestRegressor(n_estimators=100, random_state=RANDOM_SEED),
        "Gradient Boosting Regressor": GradientBoostingRegressor(n_estimators=100, random_state=RANDOM_SEED),
        "XGBoost Regressor": XGBRegressor(n_estimators=100, random_state=RANDOM_SEED, verbosity=0)
    }

    best_reg_name = None
    best_reg_pipe = None
    best_reg_metrics = {"rmse": float("inf")}
    all_reg_evaluations = {}

    for name, model in reg_candidates.items():
        preproc = build_preprocessor(mode=mode)
        pipe = Pipeline([
            ("preprocessor", preproc),
            ("regressor", model)
        ])
        pipe.fit(X_train, y_reg_train)
        y_pred = pipe.predict(X_test)
        metrics = evaluate_regression(y_reg_test.to_numpy(), y_pred)
        all_reg_evaluations[name] = metrics
        print(f"Regression [{name}] -> MAE: {metrics['mae']}, RMSE: {metrics['rmse']}, R2: {metrics['r2']}")

        if metrics["rmse"] < best_reg_metrics["rmse"]:
            best_reg_metrics = metrics
            best_reg_name = name
            best_reg_pipe = pipe

    print(f"Selected Best Regression Model: {best_reg_name}")

    # -------------------------------------------------------------
    # 2. CLASSIFICATION MODELS (4 Candidates)
    # -------------------------------------------------------------
    cls_candidates = {
        "Logistic Regression": LogisticRegression(random_state=RANDOM_SEED, max_iter=1000),
        "Random Forest Classifier": RandomForestClassifier(n_estimators=100, random_state=RANDOM_SEED),
        "Gradient Boosting Classifier": GradientBoostingClassifier(n_estimators=100, random_state=RANDOM_SEED),
        "XGBoost Classifier": XGBClassifier(n_estimators=100, random_state=RANDOM_SEED, eval_metric="logloss")
    }

    best_cls_name = None
    best_cls_pipe = None
    best_cls_metrics = {"f1": -1.0}
    all_cls_evaluations = {}

    for name, model in cls_candidates.items():
        preproc = build_preprocessor(mode=mode)
        base_pipe = Pipeline([
            ("preprocessor", preproc),
            ("classifier", model)
        ])
        
        # Apply CalibratedClassifierCV
        calibrated_model = CalibratedClassifierCV(estimator=base_pipe, cv=3)
        calibrated_model.fit(X_train, y_cls_train)

        y_pred_probs = calibrated_model.predict_proba(X_test)[:, 1]
        y_pred_labels = (y_pred_probs >= 0.5).astype(int)

        metrics = evaluate_classification(y_cls_test.to_numpy(), y_pred_labels, y_pred_probs)
        all_cls_evaluations[name] = metrics
        print(f"Classification [{name}] -> Acc: {metrics['accuracy']}, F1: {metrics['f1']}, ROC-AUC: {metrics['roc_auc']}, Brier: {metrics['brier_score']}")

        if metrics["f1"] > best_cls_metrics["f1"]:
            best_cls_metrics = metrics
            best_cls_name = name
            best_cls_pipe = calibrated_model

    print(f"Selected Best Classification Model: {best_cls_name}")

    # -------------------------------------------------------------
    # 3. SAVE ARTIFACTS
    # -------------------------------------------------------------
    reg_dir = os.path.join(ARTIFACTS_DIR, "regression")
    cls_dir = os.path.join(ARTIFACTS_DIR, "classification")
    os.makedirs(reg_dir, exist_ok=True)
    os.makedirs(cls_dir, exist_ok=True)

    timestamp = datetime.datetime.now().isoformat()

    # Save Regression
    joblib.dump(best_reg_pipe, os.path.join(reg_dir, "model.joblib"))
    with open(os.path.join(reg_dir, "metrics.json"), "w") as f:
        json.dump(best_reg_metrics, f, indent=2)
    with open(os.path.join(reg_dir, "metadata.json"), "w") as f:
        json.dump({
            "model_name": best_reg_name,
            "version": "1.0.0",
            "training_timestamp": timestamp,
            "prediction_mode": mode,
            "evaluations_comparison": all_reg_evaluations
        }, f, indent=2)

    # Save Classification
    joblib.dump(best_cls_pipe, os.path.join(cls_dir, "model.joblib"))
    with open(os.path.join(cls_dir, "metrics.json"), "w") as f:
        json.dump(best_cls_metrics, f, indent=2)
    with open(os.path.join(cls_dir, "metadata.json"), "w") as f:
        json.dump({
            "model_name": best_cls_name,
            "version": "1.0.0",
            "training_timestamp": timestamp,
            "prediction_mode": mode,
            "evaluations_comparison": all_cls_evaluations
        }, f, indent=2)

    print("ML Pipeline training and artifact persistence completed successfully!")
    return {
        "best_regression": best_reg_name,
        "best_classification": best_cls_name,
        "reg_metrics": best_reg_metrics,
        "cls_metrics": best_cls_metrics
    }

if __name__ == "__main__":
    train_and_evaluate_all(mode="performance")
