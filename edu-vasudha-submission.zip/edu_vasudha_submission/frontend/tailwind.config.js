/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#eef2ff',
          100: '#e0e7ff',
          500: '#6366f1',
          600: '#4f46e5',
          700: '#4338ca',
          900: '#312e81',
        },
        risk: {
          low: '#10b981',      // Emerald green
          moderate: '#f59e0b', // Amber
          high: '#f97316',     // Orange
          critical: '#ef4444', // Red
        },
        dark: {
          bg: '#0f172a',       // Slate 900
          card: '#1e293b',     // Slate 800
          border: '#334155',   // Slate 700
          muted: '#94a3b8',    // Slate 400
        }
      },
    },
  },
  plugins: [],
}
