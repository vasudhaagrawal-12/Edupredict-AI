import { test, expect } from '@playwright/test';

test.describe('EduPredict AI End-to-End User Flow', () => {
  test('Landing Page loads and navigates to Dashboard', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('text=EduPredict AI')).toBeVisible();
    await expect(page.locator('text=Predict Academic Outcomes')).toBeVisible();

    // Click Launch Live Demo
    await page.click('button:has-text("Launch Live Platform Demo")');
    await expect(page.locator('text=Total Student Cohort')).toBeVisible();
  });

  test('Dashboard loads student table and selects student profile', async ({ page }) => {
    await page.goto('/');
    await page.click('button:has-text("Dashboard")');
    await expect(page.locator('text=Cohort Student Registry')).toBeVisible();

    // Click first Analyze button
    const firstAnalyzeBtn = page.locator('button:has-text("Analyze")').first();
    await firstAnalyzeBtn.click();

    await expect(page.locator('text=Student Profile & Predictor')).toBeVisible();
  });

  test('Student Predictor runs inference and renders SHAP attribution', async ({ page }) => {
    await page.goto('/');
    await page.click('button:has-text("Student Predictor")');
    await expect(page.locator('text=Student Feature Predictor')).toBeVisible();

    // Submit prediction form
    await page.click('button:has-text("Run Performance & Risk Prediction")');

    // Verify results render
    await expect(page.locator('text=Explainable AI (SHAP) Attribution')).toBeVisible();
    await expect(page.locator('text=Personalized Recommendations')).toBeVisible();
  });

  test('What-If Simulator executes scenario simulation', async ({ page }) => {
    await page.goto('/');
    await page.click('button:has-text("What-If Simulator")');
    await expect(page.locator('text=Interactive What-If Scenario Simulator')).toBeVisible();

    await page.click('button:has-text("Execute Scenario Simulation")');
    await expect(page.locator('text=Baseline Score')).toBeVisible();
    await expect(page.locator('text=Simulated Score')).toBeVisible();
  });

  test('Model Lab displays evaluation metrics and confusion matrix', async ({ page }) => {
    await page.goto('/');
    await page.click('button:has-text("Model Lab")');
    await expect(page.locator('text=EduPredict Model Lab & ML Architecture')).toBeVisible();
    await expect(page.locator('text=Selected Regression Model')).toBeVisible();
    await expect(page.locator('text=Confusion Matrix')).toBeVisible();
  });

  test('CSV Upload page renders uploader UI', async ({ page }) => {
    await page.goto('/');
    await page.click('button:has-text("CSV Upload")');
    await expect(page.locator('text=Batch Student CSV Upload & Schema Validation')).toBeVisible();
  });
});
