import React, { useState, useEffect } from 'react';
import { Student, PredictionMode } from '../types';
import { Play, RotateCcw } from 'lucide-react';

interface PredictionFormProps {
  initialStudent?: Student | null;
  predictionMode: PredictionMode;
  onPredict: (student: Student) => void;
  isLoading: boolean;
}

const DEFAULT_STUDENT: Student = {
  school: 'GP',
  sex: 'F',
  age: 17,
  address: 'U',
  famsize: 'GT3',
  Pstatus: 'T',
  Medu: 2,
  Fedu: 2,
  Mjob: 'other',
  Fjob: 'other',
  reason: 'course',
  guardian: 'mother',
  traveltime: 1,
  studytime: 2,
  failures: 0,
  schoolsup: 'no',
  famsup: 'yes',
  paid: 'no',
  activities: 'no',
  nursery: 'yes',
  higher: 'yes',
  internet: 'yes',
  romantic: 'no',
  famrel: 4,
  freetime: 3,
  goout: 3,
  Dalc: 1,
  Walc: 1,
  health: 4,
  absences: 4,
  G1: 12,
  G2: 13,
};

export const PredictionForm: React.FC<PredictionFormProps> = ({
  initialStudent,
  predictionMode,
  onPredict,
  isLoading,
}) => {
  const [formData, setFormData] = useState<Student>(DEFAULT_STUDENT);

  useEffect(() => {
    if (initialStudent) {
      setFormData(initialStudent);
    }
  }, [initialStudent]);

  const handleChange = (field: keyof Student, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onPredict(formData);
  };

  const handleReset = () => {
    setFormData(DEFAULT_STUDENT);
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/60 rounded-2xl p-6 shadow-lg"
    >
      <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-700/60">
        <div>
          <h3 className="text-base font-bold text-white">Student Feature Predictor</h3>
          <p className="text-xs text-slate-400">
            Current Mode: <span className="font-semibold text-indigo-400 uppercase">{predictionMode}</span>
          </p>
        </div>
        <button
          type="button"
          onClick={handleReset}
          className="flex items-center gap-1 text-xs text-slate-400 hover:text-slate-200 transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Form</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {/* Demographics */}
        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1">Age (15-22)</label>
          <input
            type="number"
            min={15}
            max={22}
            value={formData.age}
            onChange={(e) => handleChange('age', parseInt(e.target.value))}
            className="w-full px-3 py-1.5 bg-slate-900/80 border border-slate-700 rounded-xl text-xs text-white"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1">Gender</label>
          <select
            value={formData.sex}
            onChange={(e) => handleChange('sex', e.target.value)}
            className="w-full px-3 py-1.5 bg-slate-900/80 border border-slate-700 rounded-xl text-xs text-white"
          >
            <option value="F">Female</option>
            <option value="M">Male</option>
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1">Study Time (1-4)</label>
          <select
            value={formData.studytime}
            onChange={(e) => handleChange('studytime', parseInt(e.target.value))}
            className="w-full px-3 py-1.5 bg-slate-900/80 border border-slate-700 rounded-xl text-xs text-white"
          >
            <option value={1}>1 (&lt;2 hours)</option>
            <option value={2}>2 (2-5 hours)</option>
            <option value={3}>3 (5-10 hours)</option>
            <option value={4}>4 (&gt;10 hours)</option>
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1">Past Failures (0-4)</label>
          <input
            type="number"
            min={0}
            max={4}
            value={formData.failures}
            onChange={(e) => handleChange('failures', parseInt(e.target.value))}
            className="w-full px-3 py-1.5 bg-slate-900/80 border border-slate-700 rounded-xl text-xs text-white"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1">Absences (0-93)</label>
          <input
            type="number"
            min={0}
            max={93}
            value={formData.absences}
            onChange={(e) => handleChange('absences', parseInt(e.target.value))}
            className="w-full px-3 py-1.5 bg-slate-900/80 border border-slate-700 rounded-xl text-xs text-white"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1">Workday Alcohol (1-5)</label>
          <input
            type="number"
            min={1}
            max={5}
            value={formData.Dalc}
            onChange={(e) => handleChange('Dalc', parseInt(e.target.value))}
            className="w-full px-3 py-1.5 bg-slate-900/80 border border-slate-700 rounded-xl text-xs text-white"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1">Weekend Alcohol (1-5)</label>
          <input
            type="number"
            min={1}
            max={5}
            value={formData.Walc}
            onChange={(e) => handleChange('Walc', parseInt(e.target.value))}
            className="w-full px-3 py-1.5 bg-slate-900/80 border border-slate-700 rounded-xl text-xs text-white"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1">Family Support</label>
          <select
            value={formData.famsup}
            onChange={(e) => handleChange('famsup', e.target.value)}
            className="w-full px-3 py-1.5 bg-slate-900/80 border border-slate-700 rounded-xl text-xs text-white"
          >
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </select>
        </div>

        {/* Mode B Conditional Exam Scores */}
        {predictionMode === 'performance' && (
          <>
            <div>
              <label className="block text-xs font-semibold text-amber-400 mb-1">Period 1 Score G1 (0-20)</label>
              <input
                type="number"
                min={0}
                max={20}
                value={formData.G1 ?? 10}
                onChange={(e) => handleChange('G1', parseInt(e.target.value))}
                className="w-full px-3 py-1.5 bg-slate-900/80 border border-amber-500/40 rounded-xl text-xs text-amber-300 font-mono font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-amber-400 mb-1">Period 2 Score G2 (0-20)</label>
              <input
                type="number"
                min={0}
                max={20}
                value={formData.G2 ?? 10}
                onChange={(e) => handleChange('G2', parseInt(e.target.value))}
                className="w-full px-3 py-1.5 bg-slate-900/80 border border-amber-500/40 rounded-xl text-xs text-amber-300 font-mono font-bold"
              />
            </div>
          </>
        )}
      </div>

      <div className="mt-6 flex justify-end">
        <button
          type="submit"
          disabled={isLoading}
          className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-indigo-600/30 transition-all disabled:opacity-50"
        >
          <Play className="w-4 h-4 fill-current" />
          <span>{isLoading ? 'Executing Inference...' : 'Run Performance & Risk Prediction'}</span>
        </button>
      </div>
    </form>
  );
};
