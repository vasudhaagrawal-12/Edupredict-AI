import React from 'react';
import {
  GraduationCap,
  LayoutDashboard,
  BrainCircuit,
  Sliders,
  FileSpreadsheet,
  Bot,
  Activity
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  predictionMode: 'early_warning' | 'performance';
  setPredictionMode: (mode: 'early_warning' | 'performance') => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  predictionMode,
  setPredictionMode,
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'profile', label: 'Student Predictor', icon: GraduationCap },
    { id: 'simulator', label: 'What-If Simulator', icon: Sliders },
    { id: 'model-lab', label: 'Model Lab', icon: BrainCircuit },
    { id: 'csv-upload', label: 'CSV Upload', icon: FileSpreadsheet },
    { id: 'copilot', label: 'AI Copilot', icon: Bot },
  ];

  return (
    <header className="sticky top-0 z-50 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-4 lg:px-8 py-3.5">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Brand Logo */}
        <div
          onClick={() => setActiveTab('dashboard')}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-purple-500 flex items-center justify-center shadow-lg shadow-indigo-500/20 group-hover:scale-105 transition-transform">
            <GraduationCap className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl font-bold bg-gradient-to-r from-white via-slate-100 to-indigo-300 bg-clip-text text-transparent">
                EduPredict
              </span>
              <span className="px-1.5 py-0.5 text-[10px] font-semibold tracking-wider text-indigo-400 bg-indigo-500/10 border border-indigo-500/20 rounded">
                AI
              </span>
            </div>
            <p className="text-xs text-slate-400">Student Performance & Risk Platform</p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center gap-1 bg-slate-800/60 p-1.5 rounded-xl border border-slate-700/60 overflow-x-auto max-w-full">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/50'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Mode Selector & Status */}
        <div className="flex items-center gap-3">
          <div className="flex items-center bg-slate-800/80 p-1 rounded-lg border border-slate-700 text-xs">
            <button
              onClick={() => setPredictionMode('early_warning')}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                predictionMode === 'early_warning'
                  ? 'bg-indigo-600 text-white font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Predicts without term G1/G2 exams"
            >
              Early-Warning
            </button>
            <button
              onClick={() => setPredictionMode('performance')}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                predictionMode === 'performance'
                  ? 'bg-indigo-600 text-white font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Includes mid-term G1/G2 exams"
            >
              Performance
            </button>
          </div>

          <div className="hidden xl:flex items-center gap-2 px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-medium">
            <Activity className="w-3.5 h-3.5 animate-pulse" />
            <span>API Active</span>
          </div>
        </div>
      </div>
    </header>
  );
};
