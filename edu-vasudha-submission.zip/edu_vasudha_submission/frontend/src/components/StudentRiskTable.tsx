import React, { useState } from 'react';
import { Student } from '../types';
import { RiskBadge } from './RiskBadge';
import { Search, ChevronRight, UserCheck } from 'lucide-react';

interface StudentRiskTableProps {
  students: Student[];
  onSelectStudent: (student: Student) => void;
}

export const StudentRiskTable: React.FC<StudentRiskTableProps> = ({
  students,
  onSelectStudent,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredStudents = students.filter(
    (s) =>
      s.school.toLowerCase().includes(searchTerm.toLowerCase()) ||
      String(s.id).includes(searchTerm) ||
      s.sex.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/60 rounded-2xl p-5 shadow-lg">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-4">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <UserCheck className="w-5 h-5 text-indigo-400" />
            <span>Cohort Student Registry</span>
          </h3>
          <p className="text-xs text-slate-400">
            Select a student profile to inspect predictions, SHAP attribution, and recommendations
          </p>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search student ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-1.5 bg-slate-900/80 border border-slate-700 rounded-xl text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs text-slate-300">
          <thead className="bg-slate-900/60 text-slate-400 uppercase font-semibold border-b border-slate-700/60">
            <tr>
              <th className="py-3 px-4">Student ID</th>
              <th className="py-3 px-4">Demographics</th>
              <th className="py-3 px-4">Study Time</th>
              <th className="py-3 px-4">Absences</th>
              <th className="py-3 px-4">Past Failures</th>
              <th className="py-3 px-4">Exam Scores (G1 / G2)</th>
              <th className="py-3 px-4 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {filteredStudents.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-8 text-center text-slate-500 font-medium">
                  No matching student records found.
                </td>
              </tr>
            ) : (
              filteredStudents.map((s) => (
                <tr
                  key={s.id || Math.random()}
                  onClick={() => onSelectStudent(s)}
                  className="hover:bg-slate-700/40 cursor-pointer transition-colors group"
                >
                  <td className="py-3 px-4 font-mono font-bold text-indigo-400">
                    #{s.id ?? 'New'}
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-medium text-slate-200">Age {s.age}</span> • {s.sex === 'F' ? 'Female' : 'Male'} ({s.address})
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300">
                      Level {s.studytime}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono">
                    <span className={s.absences >= 10 ? 'text-amber-400 font-bold' : 'text-slate-300'}>
                      {s.absences} days
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    {s.failures > 0 ? (
                      <span className="text-rose-400 font-bold bg-rose-500/10 border border-rose-500/20 px-2 py-0.5 rounded">
                        {s.failures} failure(s)
                      </span>
                    ) : (
                      <span className="text-emerald-400 font-medium">0</span>
                    )}
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-300">
                    {s.G1 !== undefined ? `${s.G1} / ${s.G2}` : 'Pre-Exam'}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectStudent(s);
                      }}
                      className="inline-flex items-center gap-1 text-indigo-400 hover:text-indigo-300 font-semibold group-hover:translate-x-0.5 transition-transform"
                    >
                      <span>Analyze</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
