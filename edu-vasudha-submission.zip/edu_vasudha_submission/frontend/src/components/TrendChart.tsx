import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid
} from 'recharts';

interface TrendChartProps {
  g1?: number;
  g2?: number;
  predictedG3: number;
}

export const TrendChart: React.FC<TrendChartProps> = ({
  g1,
  g2,
  predictedG3,
}) => {
  if (g1 === undefined && g2 === undefined) {
    return (
      <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/60 rounded-2xl p-5 shadow-lg flex flex-col items-center justify-center h-64 text-center">
        <p className="text-sm font-medium text-slate-300">Insufficient historical assessment data</p>
        <p className="text-xs text-slate-400 mt-1">
          Assessment progression trend requires Period 1 (G1) and Period 2 (G2) scores.
        </p>
      </div>
    );
  }

  const rawPredictedScore = Math.round((predictedG3 / 5.0) * 10) / 10;

  const data = [
    { period: 'G1 (Term 1)', score: g1 ?? 0, type: 'actual' },
    { period: 'G2 (Term 2)', score: g2 ?? g1 ?? 0, type: 'actual' },
    { period: 'Predicted G3 (Final)', score: rawPredictedScore, type: 'predicted' },
  ];

  return (
    <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/60 rounded-2xl p-5 shadow-lg">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-base font-bold text-white">Assessment Progression Trend</h3>
          <p className="text-xs text-slate-400">
            Term exam score trajectory (G1 $\to$ G2 $\to$ Model Predicted G3)
          </p>
        </div>
        <div className="flex items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-indigo-500"></span>
            <span className="text-slate-300">Actual Grade</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
            <span className="text-slate-300">Predicted</span>
          </div>
        </div>
      </div>

      <div className="h-56 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
            <XAxis dataKey="period" stroke="#94a3b8" fontSize={11} />
            <YAxis domain={[0, 20]} stroke="#94a3b8" fontSize={11} />
            <Tooltip
              contentStyle={{
                backgroundColor: '#1e293b',
                borderColor: '#334155',
                borderRadius: '0.75rem',
                color: '#fff',
                fontSize: '12px',
              }}
              formatter={(val: any) => [`${val} / 20`, 'Score']}
            />
            <Line
              type="monotone"
              dataKey="score"
              stroke="#6366f1"
              strokeWidth={3}
              dot={{ r: 5, fill: '#6366f1' }}
              activeDot={{ r: 7 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
