import React from 'react';
import { ModelLabData } from '../types';
import { Award, CheckCircle2, Shield } from 'lucide-react';

interface ModelComparisonProps {
  data: ModelLabData;
}

export const ModelComparison: React.FC<ModelComparisonProps> = ({ data }) => {
  const regMetrics = data.regression.metrics;
  const clsMetrics = data.classification.metrics;

  const regEvaluations = data.regression.all_evaluations || {};
  const clsEvaluations = data.classification.all_evaluations || {};

  const cm = clsMetrics.confusion_matrix || [[0, 0], [0, 0]];

  return (
    <div className="space-y-8">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-slate-800/50 backdrop-blur-sm border border-indigo-500/30 rounded-2xl p-6 shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold uppercase tracking-wider text-indigo-400">Selected Regression Model</span>
            <Award className="w-5 h-5 text-indigo-400" />
          </div>
          <h3 className="text-xl font-bold text-white mb-4">{data.regression.selected_model}</h3>
          
          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="bg-slate-900/60 p-2.5 rounded-xl border border-slate-700">
              <span className="text-[10px] text-slate-400 uppercase">MAE</span>
              <p className="text-lg font-bold text-indigo-300 font-mono">{regMetrics.mae ?? 'N/A'}</p>
            </div>
            <div className="bg-slate-900/60 p-2.5 rounded-xl border border-slate-700">
              <span className="text-[10px] text-slate-400 uppercase">RMSE</span>
              <p className="text-lg font-bold text-indigo-300 font-mono">{regMetrics.rmse ?? 'N/A'}</p>
            </div>
            <div className="bg-slate-900/60 p-2.5 rounded-xl border border-slate-700">
              <span className="text-[10px] text-slate-400 uppercase">R² Score</span>
              <p className="text-lg font-bold text-indigo-300 font-mono">{regMetrics.r2 ?? 'N/A'}</p>
            </div>
          </div>
        </div>

        <div className="bg-slate-800/50 backdrop-blur-sm border border-purple-500/30 rounded-2xl p-6 shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold uppercase tracking-wider text-purple-400">Selected Classification Model</span>
            <Shield className="w-5 h-5 text-purple-400" />
          </div>
          <h3 className="text-xl font-bold text-white mb-4">{data.classification.selected_model}</h3>
          
          <div className="grid grid-cols-4 gap-2 text-center">
            <div className="bg-slate-900/60 p-2.5 rounded-xl border border-slate-700">
              <span className="text-[10px] text-slate-400 uppercase">Accuracy</span>
              <p className="text-sm font-bold text-purple-300 font-mono">{(clsMetrics.accuracy! * 100).toFixed(1)}%</p>
            </div>
            <div className="bg-slate-900/60 p-2.5 rounded-xl border border-slate-700">
              <span className="text-[10px] text-slate-400 uppercase">F1 Score</span>
              <p className="text-sm font-bold text-purple-300 font-mono">{clsMetrics.f1 ?? 'N/A'}</p>
            </div>
            <div className="bg-slate-900/60 p-2.5 rounded-xl border border-slate-700">
              <span className="text-[10px] text-slate-400 uppercase">ROC-AUC</span>
              <p className="text-sm font-bold text-purple-300 font-mono">{clsMetrics.roc_auc ?? 'N/A'}</p>
            </div>
            <div className="bg-slate-900/60 p-2.5 rounded-xl border border-slate-700">
              <span className="text-[10px] text-slate-400 uppercase">Brier</span>
              <p className="text-sm font-bold text-purple-300 font-mono">{clsMetrics.brier_score ?? 'N/A'}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Regression Candidates Table */}
      <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/60 rounded-2xl p-6 shadow-lg">
        <h3 className="text-base font-bold text-white mb-4">Regression Candidate Models (5 Evaluated)</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-900/60 text-slate-400 uppercase font-semibold border-b border-slate-700">
              <tr>
                <th className="py-3 px-4">Model Candidate</th>
                <th className="py-3 px-4">MAE</th>
                <th className="py-3 px-4">RMSE</th>
                <th className="py-3 px-4">R² Score</th>
                <th className="py-3 px-4 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {Object.entries(regEvaluations).map(([name, m]) => (
                <tr key={name} className={name === data.regression.selected_model ? 'bg-indigo-500/10' : ''}>
                  <td className="py-3 px-4 font-semibold text-white">{name}</td>
                  <td className="py-3 px-4 font-mono">{m.mae}</td>
                  <td className="py-3 px-4 font-mono">{m.rmse}</td>
                  <td className="py-3 px-4 font-mono">{m.r2}</td>
                  <td className="py-3 px-4 text-right">
                    {name === data.regression.selected_model ? (
                      <span className="inline-flex items-center gap-1 text-emerald-400 font-bold">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Selected
                      </span>
                    ) : (
                      <span className="text-slate-500">Candidate</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Classification Candidates & Confusion Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-slate-800/50 backdrop-blur-sm border border-slate-700/60 rounded-2xl p-6 shadow-lg">
          <h3 className="text-base font-bold text-white mb-4">Classification Candidate Models (4 Evaluated)</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-900/60 text-slate-400 uppercase font-semibold border-b border-slate-700">
                <tr>
                  <th className="py-3 px-4">Model Candidate</th>
                  <th className="py-3 px-4">Accuracy</th>
                  <th className="py-3 px-4">Precision</th>
                  <th className="py-3 px-4">Recall</th>
                  <th className="py-3 px-4">F1 Score</th>
                  <th className="py-3 px-4">ROC-AUC</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {Object.entries(clsEvaluations).map(([name, m]) => (
                  <tr key={name} className={name === data.classification.selected_model ? 'bg-purple-500/10' : ''}>
                    <td className="py-3 px-4 font-semibold text-white">{name}</td>
                    <td className="py-3 px-4 font-mono">{((m.accuracy || 0) * 100).toFixed(1)}%</td>
                    <td className="py-3 px-4 font-mono">{m.precision}</td>
                    <td className="py-3 px-4 font-mono">{m.recall}</td>
                    <td className="py-3 px-4 font-mono font-bold text-indigo-300">{m.f1}</td>
                    <td className="py-3 px-4 font-mono">{m.roc_auc}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Confusion Matrix Card */}
        <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/60 rounded-2xl p-6 shadow-lg flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-white mb-1">Confusion Matrix</h3>
            <p className="text-xs text-slate-400 mb-4">Test set classification matrix for selected model</p>
            
            <div className="grid grid-cols-2 gap-2 text-center text-xs font-mono font-bold">
              <div className="bg-emerald-500/10 border border-emerald-500/30 p-4 rounded-xl">
                <span className="text-[10px] text-slate-400 block mb-1">True Negative (Pass)</span>
                <span className="text-2xl text-emerald-400">{cm[0]?.[0] ?? 0}</span>
              </div>
              <div className="bg-rose-500/10 border border-rose-500/30 p-4 rounded-xl">
                <span className="text-[10px] text-slate-400 block mb-1">False Positive</span>
                <span className="text-2xl text-rose-400">{cm[0]?.[1] ?? 0}</span>
              </div>
              <div className="bg-amber-500/10 border border-amber-500/30 p-4 rounded-xl">
                <span className="text-[10px] text-slate-400 block mb-1">False Negative</span>
                <span className="text-2xl text-amber-400">{cm[1]?.[0] ?? 0}</span>
              </div>
              <div className="bg-indigo-500/10 border border-indigo-500/30 p-4 rounded-xl">
                <span className="text-[10px] text-slate-400 block mb-1">True Positive (Risk)</span>
                <span className="text-2xl text-indigo-400">{cm[1]?.[1] ?? 0}</span>
              </div>
            </div>
          </div>
          <p className="text-[11px] text-slate-400 mt-4 italic text-center">
            Evaluated on held-out test dataset (20% split).
          </p>
        </div>
      </div>
    </div>
  );
};
