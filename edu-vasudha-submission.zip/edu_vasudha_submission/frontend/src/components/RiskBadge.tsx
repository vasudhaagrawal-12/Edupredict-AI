import React from 'react';
import { RiskCategory } from '../types';
import { RISK_COLOR_MAP } from '../utils/theme';
import { ShieldCheck, ShieldAlert, AlertTriangle, AlertOctagon } from 'lucide-react';

interface RiskBadgeProps {
  category: RiskCategory;
  score?: number;
  showIcon?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export const RiskBadge: React.FC<RiskBadgeProps> = ({
  category,
  score,
  showIcon = true,
  size = 'md',
}) => {
  const colors = RISK_COLOR_MAP[category] || RISK_COLOR_MAP.LOW;

  const IconMap = {
    LOW: ShieldCheck,
    MODERATE: AlertTriangle,
    HIGH: ShieldAlert,
    CRITICAL: AlertOctagon,
  };
  const Icon = IconMap[category] || ShieldCheck;

  const sizeClasses = {
    sm: 'px-2 py-0.5 text-xs gap-1',
    md: 'px-2.5 py-1 text-xs font-semibold gap-1.5',
    lg: 'px-3 py-1.5 text-sm font-bold gap-2',
  };

  return (
    <span
      className={`inline-flex items-center rounded-full border ${colors.badge} ${colors.glow} ${sizeClasses[size]}`}
    >
      {showIcon && <Icon className="w-3.5 h-3.5" />}
      <span>{category} RISK</span>
      {score !== undefined && (
        <span className="opacity-75 font-mono ml-0.5">({score})</span>
      )}
    </span>
  );
};
