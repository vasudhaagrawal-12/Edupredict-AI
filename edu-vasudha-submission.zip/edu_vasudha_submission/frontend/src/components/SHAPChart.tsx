import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
  ReferenceLine
} from 'recharts';
import { FeatureContribution } from '../types';
import { formatFeatureName } from '../utils/theme';

interface SHAPChartProps {
  topPositives: FeatureContribution[];
  topNegatives: FeatureContribution[];
}

export const SHAPChart: React.FC<SHAPChartProps> = ({
  topPositives,
  topNegatives,
}) => {
  const data = [
    ...topPositives.map((item) => ({
      name: formatFeatureName(item.feature),
      importance: item.importance,
      direction: 'positive',
    })),
    ...topNegatives.map((item) => ({
      name: formatFeatureName(item.feature),
      importance: item.importance,
      direction: 'negative',
    })),
  ].sort((a, b) => Math.abs(b.importance) - Math.abs(a.importance));

  return (
    <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/60 rounded-2xl p-5 shadow-lg">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <span>Explainable AI (SHAP) Attribution</span>
          </h3>
          <p className="text-xs text-slate-400">
            Local model feature contributions to student prediction score
          </p>
        </div>
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded bg-emerald-500"></span>
            <span className="text-slate-300">Positive Impact</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded bg-rose-500"></span>
            <span className="text-slate-300">Negative Impact</span>
          </div>
        </div>
      </div>

      <div className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            layout="vertical"
            data={data}
            margin={{ top: 5, right: 30, left: 100, bottom: 5 }}
          >
            <XAxis type="number" stroke="#94a3b8" fontSize={11} />
            <YAxis
              type="category"
              dataKey="name"
              stroke="#cbd5e1"
              fontSize={11}
              width={110}
              tickLine={false}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: '#1e293b',
                borderColor: '#334155',
                borderRadius: '0.75rem',
                color: '#fff',
                fontSize: '12px',
              }}
              formatter={(val: any) => [val, 'SHAP Value']}
            />
            <ReferenceLine x={0} stroke="#475569" />
            <Bar dataKey="importance" radius={[4, 4, 4, 4]}>
              {data.map((entry, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={entry.importance > 0 ? '#10b981' : '#f43f5e'}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      <p className="text-[11px] text-slate-400 mt-3 italic text-center">
        Note: SHAP values describe model feature attributions for this prediction and do not prove causal relationships.
      </p>
    </div>
  );
};
