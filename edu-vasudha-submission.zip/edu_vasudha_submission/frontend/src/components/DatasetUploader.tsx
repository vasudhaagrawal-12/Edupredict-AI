import React, { useState } from 'react';
import { CSVValidationResponse } from '../types';
import { ApiService } from '../services/api';
import { Upload, FileCheck, AlertTriangle, CheckCircle2 } from 'lucide-react';

export const DatasetUploader: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [validation, setValidation] = useState<CSVValidationResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      setUploadSuccess(false);
      setIsLoading(true);

      try {
        const res = await ApiService.validateCSV(file);
        setValidation(res);
      } catch (err: any) {
        alert(`CSV Validation Failed: ${err.message}`);
        setValidation(null);
      } finally {
        setIsLoading(false);
      }
    }
  };

  const handleUploadConfirm = async () => {
    if (!selectedFile) return;
    setIsLoading(true);
    try {
      await ApiService.uploadCSV(selectedFile);
      setUploadSuccess(true);
    } catch (err: any) {
      alert(`Upload failed: ${err.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Upload Zone */}
      <div className="bg-slate-800/50 backdrop-blur-sm border-2 border-dashed border-slate-700 hover:border-indigo-500/50 transition-colors rounded-2xl p-8 text-center shadow-lg">
        <Upload className="w-12 h-12 text-indigo-400 mx-auto mb-3" />
        <h3 className="text-base font-bold text-white mb-1">Batch Student CSV Upload & Schema Validation</h3>
        <p className="text-xs text-slate-400 max-w-md mx-auto mb-4">
          Upload custom student dataset CSV files. Supports UCI semicolon (;) and standard comma (,) delimitation.
        </p>

        <label className="inline-flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl cursor-pointer shadow-lg shadow-indigo-600/30 transition-all">
          <span>Choose CSV File</span>
          <input type="file" accept=".csv" onChange={handleFileChange} className="hidden" />
        </label>

        {selectedFile && (
          <p className="text-xs text-slate-300 font-mono mt-3">Selected: {selectedFile.name}</p>
        )}
      </div>

      {/* Validation Summary Report */}
      {validation && (
        <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/60 rounded-2xl p-6 shadow-lg space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <FileCheck className="w-5 h-5 text-emerald-400" />
              <span>Validation Summary Report</span>
            </h3>
            <div className="flex items-center gap-3">
              <span className="text-xs font-mono text-slate-400">File: {validation.filename}</span>
              <button
                onClick={handleUploadConfirm}
                disabled={isLoading || validation.valid_rows === 0}
                className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg transition-all disabled:opacity-50 flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Import {validation.valid_rows} Valid Rows</span>
              </button>
            </div>
          </div>

          {uploadSuccess && (
            <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 p-3 rounded-xl text-xs font-semibold">
              Dataset successfully processed and imported into EduPredict database!
            </div>
          )}

          <div className="grid grid-cols-3 gap-4 text-center">
            <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-700">
              <span className="text-[11px] text-slate-400 uppercase">Total Rows</span>
              <p className="text-xl font-bold text-white font-mono">{validation.total_rows}</p>
            </div>
            <div className="bg-emerald-500/10 p-3 rounded-xl border border-emerald-500/30">
              <span className="text-[11px] text-emerald-400 uppercase">Valid Rows</span>
              <p className="text-xl font-bold text-emerald-400 font-mono">{validation.valid_rows}</p>
            </div>
            <div className="bg-rose-500/10 p-3 rounded-xl border border-rose-500/30">
              <span className="text-[11px] text-rose-400 uppercase">Invalid Rows</span>
              <p className="text-xl font-bold text-rose-400 font-mono">{validation.invalid_rows}</p>
            </div>
          </div>

          {/* Validation Errors Table */}
          {validation.errors.length > 0 && (
            <div>
              <h4 className="text-xs font-bold text-rose-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4" />
                <span>Detected Validation Errors ({validation.errors.length})</span>
              </h4>
              <div className="max-h-48 overflow-y-auto bg-slate-900/80 rounded-xl border border-slate-700 p-3">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="text-slate-400 font-semibold border-b border-slate-700">
                    <tr>
                      <th className="pb-2">Row #</th>
                      <th className="pb-2">Column</th>
                      <th className="pb-2">Error Detail</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {validation.errors.map((err, i) => (
                      <tr key={i}>
                        <td className="py-1.5 font-mono text-rose-400">Row {err.row_index}</td>
                        <td className="py-1.5 font-semibold text-slate-200">{err.column}</td>
                        <td className="py-1.5 text-slate-400">{err.error_message}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
