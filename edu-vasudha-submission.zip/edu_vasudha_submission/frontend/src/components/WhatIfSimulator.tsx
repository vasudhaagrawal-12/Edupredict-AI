import React, { useState } from 'react';
import { Student, PredictionMode, SimulationResponse } from '../types';
import { ApiService } from '../services/api';
import { RiskBadge } from './RiskBadge';
import { Sliders, RefreshCw, AlertCircle } from 'lucide-react';

interface WhatIfSimulatorProps {
  baselineStudent: Student;
  predictionMode: PredictionMode;
}

export const WhatIfSimulator: React.FC<WhatIfSimulatorProps> = ({
  baselineStudent,
  predictionMode,
}) => {
  const [studytime, setStudytime] = useState(baselineStudent.studytime);
  const [absences, setAbsences] = useState(baselineStudent.absences);
  const [g1, setG1] = useState(baselineStudent.G1 ?? 10);
  const [g2, setG2] = useState(baselineStudent.G2 ?? 10);

  const [simulation, setSimulation] = useState<SimulationResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSimulate = async () => {
    setIsLoading(true);
    const modified: Student = {
      ...baselineStudent,
      studytime,
      absences,
      G1: g1,
      G2: g2,
    };

    try {
      const res = await ApiService.runSimulation(baselineStudent, modified, predictionMode);
      setSimulation(res);
    } catch (err: any) {
      alert(`Simulation failed: ${err.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/60 rounded-2xl p-6 shadow-lg">
      <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-700/60">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Sliders className="w-5 h-5 text-indigo-400" />
            <span>Interactive What-If Scenario Simulator</span>
          </h3>
          <p className="text-xs text-slate-400">
            Adjust student intervention variables and observe instant ML model prediction response
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Sliders Input Column */}
        <div className="space-y-5">
          {/* Study Time Slider */}
          <div>
            <div className="flex justify-between text-xs font-semibold mb-1">
              <span className="text-slate-300">Weekly Study Time</span>
              <span className="text-indigo-400 font-mono">Level {studytime} ({studytime === 1 ? '<2h' : studytime === 2 ? '2-5h' : studytime === 3 ? '5-10h' : '>10h'})</span>
            </div>
            <input
              type="range"
              min={1}
              max={4}
              value={studytime}
              onChange={(e) => setStudytime(parseInt(e.target.value))}
              className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
            />
          </div>

          {/* Absences Slider */}
          <div>
            <div className="flex justify-between text-xs font-semibold mb-1">
              <span className="text-slate-300">School Absences</span>
              <span className="text-amber-400 font-mono">{absences} days</span>
            </div>
            <input
              type="range"
              min={0}
              max={30}
              value={absences}
              onChange={(e) => setAbsences(parseInt(e.target.value))}
              className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-amber-500"
            />
          </div>

          {/* Period Exam Scores Sliders (Performance Mode) */}
          {predictionMode === 'performance' && (
            <>
              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-slate-300">Simulated Period 1 Score (G1)</span>
                  <span className="text-emerald-400 font-mono">{g1} / 20</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={20}
                  value={g1}
                  onChange={(e) => setG1(parseInt(e.target.value))}
                  className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-slate-300">Simulated Period 2 Score (G2)</span>
                  <span className="text-emerald-400 font-mono">{g2} / 20</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={20}
                  value={g2}
                  onChange={(e) => setG2(parseInt(e.target.value))}
                  className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                />
              </div>
            </>
          )}

          <button
            onClick={handleSimulate}
            disabled={isLoading}
            className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-indigo-600/30 transition-all flex items-center justify-center gap-2"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Execute Scenario Simulation</span>
          </button>
        </div>

        {/* Results Column */}
        <div className="bg-slate-900/60 border border-slate-700/60 rounded-xl p-5 flex flex-col justify-between">
          {simulation ? (
            <div className="space-y-5">
              <div className="grid grid-cols-2 gap-4 text-center">
                <div className="bg-slate-800/80 p-3.5 rounded-xl border border-slate-700">
                  <span className="text-[11px] uppercase tracking-wider text-slate-400">Baseline Score</span>
                  <p className="text-2xl font-bold text-slate-300 font-mono">{simulation.baseline_predicted_score}</p>
                  <div className="mt-1">
                    <RiskBadge category={simulation.baseline_risk_category} size="sm" />
                  </div>
                </div>

                <div className="bg-slate-800/80 p-3.5 rounded-xl border border-indigo-500/30">
                  <span className="text-[11px] uppercase tracking-wider text-indigo-400">Simulated Score</span>
                  <p className="text-2xl font-bold text-emerald-400 font-mono">{simulation.simulated_predicted_score}</p>
                  <div className="mt-1">
                    <RiskBadge category={simulation.simulated_risk_category} size="sm" />
                  </div>
                </div>
              </div>

              {/* Delta Box */}
              <div className="bg-slate-800/90 p-4 rounded-xl border border-slate-700 flex justify-around items-center">
                <div className="text-center">
                  <span className="text-xs text-slate-400">Predicted Score Delta</span>
                  <p className={`text-xl font-bold font-mono ${simulation.score_delta >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {simulation.score_delta >= 0 ? `+${simulation.score_delta}` : simulation.score_delta} pts
                  </p>
                </div>

                <div className="h-8 w-px bg-slate-700"></div>

                <div className="text-center">
                  <span className="text-xs text-slate-400">Risk Indicator Delta</span>
                  <p className={`text-xl font-bold font-mono ${simulation.risk_score_delta <= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {simulation.risk_score_delta <= 0 ? `${simulation.risk_score_delta}` : `+${simulation.risk_score_delta}`}
                  </p>
                </div>
              </div>

              {/* Non-Causal Disclaimer */}
              <div className="flex items-start gap-2 text-[11px] text-amber-400/90 bg-amber-500/10 border border-amber-500/20 p-3 rounded-lg">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <p>{simulation.disclaimer}</p>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-center p-8 text-slate-400">
              <Sliders className="w-8 h-8 text-slate-600 mb-2" />
              <p className="text-sm font-medium">Adjust sliders and click "Execute Scenario Simulation"</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
