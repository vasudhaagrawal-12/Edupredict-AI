import {
  Student,
  PredictionResponse,
  PredictionMode,
  SimulationResponse,
  CSVValidationResponse,
  ModelLabData,
  CopilotResponse
} from '../types';

const API_BASE = '/api';

async function fetchJSON<T>(url: string, options?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE}${url}`, {
    headers: {
      'Content-Type': 'application/json',
      ...options?.headers,
    },
    ...options,
  });

  if (!response.ok) {
    const errorText = await response.text();
    let message = `HTTP Error ${response.status}`;
    try {
      const errJson = JSON.parse(errorText);
      message = errJson.detail || errJson.message || message;
    } catch {
      message = errorText || message;
    }
    throw new Error(message);
  }

  return response.json();
}

export const ApiService = {
  async getHealth() {
    return fetchJSON<{ status: string; models_loaded: string[] }>('/health');
  },

  async getStudents(): Promise<Student[]> {
    return fetchJSON<Student[]>('/students');
  },

  async getStudent(id: number): Promise<Student> {
    return fetchJSON<Student>(`/students/${id}`);
  },

  async predictStudent(student: Student, mode: PredictionMode = 'performance'): Promise<PredictionResponse> {
    return fetchJSON<PredictionResponse>('/predictions', {
      method: 'POST',
      body: JSON.stringify({
        prediction_mode: mode,
        student_id: student.id,
        features: student,
      }),
    });
  },

  async runSimulation(
    baseline: Student,
    modified: Student,
    mode: PredictionMode = 'performance'
  ): Promise<SimulationResponse> {
    return fetchJSON<SimulationResponse>('/simulations', {
      method: 'POST',
      body: JSON.stringify({
        prediction_mode: mode,
        baseline_features: baseline,
        modified_features: modified,
      }),
    });
  },

  async validateCSV(file: File): Promise<CSVValidationResponse> {
    const formData = new FormData();
    formData.append('file', file);

    const response = await fetch(`${API_BASE}/datasets/validate`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({ detail: 'Failed to validate CSV' }));
      throw new Error(err.detail || 'Validation failed');
    }

    return response.json();
  },

  async uploadCSV(file: File) {
    const formData = new FormData();
    formData.append('file', file);

    const response = await fetch(`${API_BASE}/datasets/upload`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({ detail: 'Failed to upload CSV' }));
      throw new Error(err.detail || 'Upload failed');
    }

    return response.json();
  },

  async getModelLab(): Promise<ModelLabData> {
    return fetchJSON<ModelLabData>('/models');
  },

  async getEDA(): Promise<any> {
    return fetchJSON<any>('/eda');
  },

  async queryCopilot(query: string, studentContext?: PredictionResponse): Promise<CopilotResponse> {
    return fetchJSON<CopilotResponse>('/copilot', {
      method: 'POST',
      body: JSON.stringify({
        query,
        prediction_context: studentContext,
      }),
    });
  },
};
