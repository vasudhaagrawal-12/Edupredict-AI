export type RiskCategory = 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';
export type PredictionMode = 'early_warning' | 'performance';

export interface Student {
  id?: number;
  school: string;
  sex: string;
  age: number;
  address: string;
  famsize: string;
  Pstatus: string;
  Medu: number;
  Fedu: number;
  Mjob: string;
  Fjob: string;
  reason: string;
  guardian: string;
  traveltime: number;
  studytime: number;
  failures: number;
  schoolsup: string;
  famsup: string;
  paid: string;
  activities: string;
  nursery: string;
  higher: string;
  internet: string;
  romantic: string;
  famrel: number;
  freetime: number;
  goout: number;
  Dalc: number;
  Walc: number;
  health: number;
  absences: number;
  G1?: number;
  G2?: number;
  G3?: number;
}

export interface FeatureContribution {
  feature: string;
  importance: number;
  direction: 'positive' | 'negative';
}

export interface EarlyWarningSignal {
  code: string;
  severity: 'HIGH' | 'MODERATE' | 'LOW';
  message: string;
}

export interface Recommendation {
  area: string;
  action: string;
  impact: string;
}

export interface PredictionResponse {
  prediction_mode: PredictionMode;
  predicted_score: number;
  pass_probability: number;
  risk_probability: number;
  risk_score: number;
  risk_category: RiskCategory;
  is_anomaly: boolean;
  anomaly_description: string;
  top_positive_contributors: FeatureContribution[];
  top_negative_contributors: FeatureContribution[];
  early_warnings: EarlyWarningSignal[];
  recommendations: Recommendation[];
}

export interface SimulationResponse {
  baseline_predicted_score: number;
  simulated_predicted_score: number;
  score_delta: number;
  baseline_risk_score: number;
  simulated_risk_score: number;
  risk_score_delta: number;
  baseline_risk_category: RiskCategory;
  simulated_risk_category: RiskCategory;
  disclaimer: string;
}

export interface DatasetValidationError {
  row_index: number;
  column: string;
  error_message: string;
}

export interface CSVValidationResponse {
  filename: string;
  total_rows: number;
  valid_rows: number;
  invalid_rows: number;
  errors: DatasetValidationError[];
  sample_preview: Record<string, any>[];
}

export interface ModelMetrics {
  mae?: number;
  rmse?: number;
  r2?: number;
  accuracy?: number;
  precision?: number;
  recall?: number;
  f1?: number;
  roc_auc?: number;
  pr_auc?: number;
  brier_score?: number;
  confusion_matrix?: number[][];
}

export interface ModelLabData {
  regression: {
    selected_model: string;
    metrics: ModelMetrics;
    all_evaluations: Record<string, ModelMetrics>;
  };
  classification: {
    selected_model: string;
    metrics: ModelMetrics;
    all_evaluations: Record<string, ModelMetrics>;
  };
}

export interface CopilotResponse {
  query: string;
  answer: string;
  grounded_context_used: boolean;
}
