import { RiskCategory } from '../types';

export const RISK_COLOR_MAP: Record<RiskCategory, {
  badge: string;
  border: string;
  bg: string;
  text: string;
  glow: string;
}> = {
  LOW: {
    badge: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    border: 'border-emerald-500/40',
    bg: 'bg-emerald-950/20',
    text: 'text-emerald-400',
    glow: 'shadow-[0_0_15px_rgba(16,185,129,0.25)]',
  },
  MODERATE: {
    badge: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
    border: 'border-amber-500/40',
    bg: 'bg-amber-950/20',
    text: 'text-amber-400',
    glow: 'shadow-[0_0_15px_rgba(245,158,11,0.25)]',
  },
  HIGH: {
    badge: 'bg-orange-500/10 text-orange-400 border-orange-500/30',
    border: 'border-orange-500/40',
    bg: 'bg-orange-950/20',
    text: 'text-orange-400',
    glow: 'shadow-[0_0_15px_rgba(249,115,22,0.25)]',
  },
  CRITICAL: {
    badge: 'bg-rose-500/10 text-rose-400 border-rose-500/30',
    border: 'border-rose-500/40',
    bg: 'bg-rose-950/20',
    text: 'text-rose-400',
    glow: 'shadow-[0_0_15px_rgba(244,63,94,0.3)]',
  },
};

export function formatFeatureName(name: string): string {
  const map: Record<string, string> = {
    studytime: 'Weekly Study Time',
    absences: 'School Absences',
    failures: 'Past Failures',
    traveltime: 'Travel Time',
    famrel: 'Family Relationship Quality',
    freetime: 'Free Time',
    goout: 'Socializing Frequency',
    Dalc: 'Workday Alcohol Intake',
    Walc: 'Weekend Alcohol Intake',
    health: 'Health Status',
    G1: 'Period 1 Exam Score',
    G2: 'Period 2 Exam Score',
    alcohol_consumption_index: 'Alcohol Consumption Index',
    family_support_score: 'Family Support Index',
    assessment_trend: 'Assessment Score Trend',
    past_failures_flag: 'Prior Failure Flag',
  };
  return map[name] || name.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
}
