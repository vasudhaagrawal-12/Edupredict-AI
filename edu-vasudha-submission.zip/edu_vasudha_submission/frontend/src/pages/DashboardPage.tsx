import React, { useEffect, useState } from 'react';
import { Student } from '../types';
import { ApiService } from '../services/api';
import { MetricCard } from '../components/MetricCard';
import { StudentRiskTable } from '../components/StudentRiskTable';
import { Users, GraduationCap, ShieldAlert, Activity, AlertTriangle } from 'lucide-react';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts';

interface DashboardPageProps {
  onSelectStudent: (student: Student) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onSelectStudent }) => {
  const [students, setStudents] = useState<Student[]>([]);
  const [eda, setEda] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      try {
        const studentList = await ApiService.getStudents();
        setStudents(studentList);

        const edaData = await ApiService.getEDA().catch(() => null);
        setEda(edaData);
      } catch (err) {
        console.error('Failed to load dashboard data:', err);
      } finally {
        setIsLoading(false);
      }
    }
    loadData();
  }, []);

  const totalStudents = eda?.total_students || students.length || 395;
  const meanMarks = eda?.score_distribution?.mean_final_marks || 52.1;
  const riskRate = eda?.risk_distribution?.risk_rate_pct || 32.9;

  const pieData = [
    { name: 'Passing Students', value: eda?.risk_distribution?.passing_students || 265, color: '#10b981' },
    { name: 'At Risk Students', value: eda?.risk_distribution?.at_risk_students || 130, color: '#ef4444' },
  ];

  return (
    <div className="space-y-8 py-4">
      {/* Metric Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <MetricCard
          title="Total Student Cohort"
          value={totalStudents}
          subtitle="UCI Student Performance Dataset"
          icon={Users}
          trend="+100%"
          trendType="positive"
        />

        <MetricCard
          title="Cohort Mean Marks"
          value={`${meanMarks} / 100`}
          subtitle="Median mark: 55.0 / 100"
          icon={GraduationCap}
          trend="Baseline"
          trendType="neutral"
        />

        <MetricCard
          title="Cohort Failure Risk Rate"
          value={`${riskRate}%`}
          subtitle="130 at-risk students (<50% threshold)"
          icon={ShieldAlert}
          trend="Early Warning"
          trendType="negative"
        />

        <MetricCard
          title="ML System Status"
          value="Online"
          subtitle="5 Regressor & 4 Classifier candidates"
          icon={Activity}
          trend="Calibrated"
          trendType="positive"
        />
      </div>

      {/* Cohort Overview & Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-slate-800/50 backdrop-blur-sm border border-slate-700/60 rounded-2xl p-6 shadow-lg">
          <h3 className="text-base font-bold text-white mb-2">Early Warning Signal Stream</h3>
          <p className="text-xs text-slate-400 mb-4">
            Recent empirical alerts generated across active cohort profiles
          </p>

          <div className="space-y-3">
            <div className="bg-rose-500/10 border border-rose-500/30 p-3.5 rounded-xl flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-rose-300">High Absence Frequency</span>
                  <span className="text-[10px] bg-rose-500/20 text-rose-400 px-1.5 py-0.5 rounded font-mono">15+ Absences</span>
                </div>
                <p className="text-xs text-slate-300 mt-1">
                  18 students in the cohort currently have excessive absences correlated with a 42% increase in predicted failure risk.
                </p>
              </div>
            </div>

            <div className="bg-amber-500/10 border border-amber-500/30 p-3.5 rounded-xl flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-amber-300">Prior Academic Vulnerability</span>
                  <span className="text-[10px] bg-amber-500/20 text-amber-400 px-1.5 py-0.5 rounded font-mono">Failures &gt; 0</span>
                </div>
                <p className="text-xs text-slate-300 mt-1">
                  Students with 1 or more past course failures show an average predicted score drop of 15.2 points.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Cohort Risk Pie Chart */}
        <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/60 rounded-2xl p-6 shadow-lg flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-white mb-1">Pass vs Risk Distribution</h3>
            <p className="text-xs text-slate-400 mb-2">Overall cohort classification split</p>

            <div className="h-44 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={65}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1e293b',
                      borderColor: '#334155',
                      borderRadius: '0.75rem',
                      color: '#fff',
                      fontSize: '12px',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="flex justify-around text-xs font-semibold text-slate-300">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded bg-emerald-500"></span>
              <span>Passing ({pieData[0].value})</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded bg-rose-500"></span>
              <span>At Risk ({pieData[1].value})</span>
            </div>
          </div>
        </div>
      </div>

      {/* Cohort Student Table */}
      <StudentRiskTable students={students} onSelectStudent={onSelectStudent} />
    </div>
  );
};
