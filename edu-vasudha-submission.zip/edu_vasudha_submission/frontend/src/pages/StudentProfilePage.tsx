import React, { useState } from 'react';
import { Student, PredictionMode, PredictionResponse } from '../types';
import { ApiService } from '../services/api';
import { PredictionForm } from '../components/PredictionForm';
import { RiskBadge } from '../components/RiskBadge';
import { SHAPChart } from '../components/SHAPChart';
import { TrendChart } from '../components/TrendChart';
import { CheckCircle2, AlertTriangle, Lightbulb } from 'lucide-react';

interface StudentProfilePageProps {
  selectedStudent: Student | null;
  predictionMode: PredictionMode;
}

export const StudentProfilePage: React.FC<StudentProfilePageProps> = ({
  selectedStudent,
  predictionMode,
}) => {
  const [prediction, setPrediction] = useState<PredictionResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handlePredict = async (studentData: Student) => {
    setIsLoading(true);
    try {
      const res = await ApiService.predictStudent(studentData, predictionMode);
      setPrediction(res);
    } catch (err: any) {
      alert(`Prediction failed: ${err.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-8 py-4">
      {/* Top Banner */}
      <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/60 rounded-2xl p-6 shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-indigo-400">Student Profile & Predictor</span>
          <h2 className="text-2xl font-extrabold text-white mt-1">
            {selectedStudent ? `Student Profile #${selectedStudent.id}` : 'Custom Student Analysis'}
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Active Mode: <span className="text-slate-200 font-semibold uppercase">{predictionMode}</span>
          </p>
        </div>

        {prediction && (
          <div className="flex items-center gap-4 bg-slate-900/80 p-3 rounded-xl border border-slate-700">
            <div>
              <span className="text-[10px] text-slate-400 uppercase block">Predicted Mark</span>
              <span className="text-2xl font-extrabold text-indigo-300 font-mono">
                {prediction.predicted_score} / 100
              </span>
            </div>
            <div className="h-8 w-px bg-slate-700"></div>
            <div>
              <span className="text-[10px] text-slate-400 uppercase block">Academic Risk</span>
              <RiskBadge category={prediction.risk_category} score={prediction.risk_score} />
            </div>
          </div>
        )}
      </div>

      {/* Prediction Form */}
      <PredictionForm
        initialStudent={selectedStudent}
        predictionMode={predictionMode}
        onPredict={handlePredict}
        isLoading={isLoading}
      />

      {/* Prediction Results & Explainability */}
      {prediction && (
        <div className="space-y-8">
          {/* Anomaly Notice */}
          {prediction.is_anomaly && (
            <div className="bg-amber-500/10 border border-amber-500/30 text-amber-300 p-4 rounded-xl text-xs flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 shrink-0 text-amber-400" />
              <div>
                <span className="font-bold">Anomaly Indicator Triggered:</span> {prediction.anomaly_description}
              </div>
            </div>
          )}

          {/* Charts Row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <SHAPChart
              topPositives={prediction.top_positive_contributors}
              topNegatives={prediction.top_negative_contributors}
            />

            <TrendChart
              g1={selectedStudent?.G1}
              g2={selectedStudent?.G2}
              predictedG3={prediction.predicted_score}
            />
          </div>

          {/* Warnings & Recommendations Row */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Early Warnings */}
            <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/60 rounded-2xl p-6 shadow-lg">
              <h3 className="text-base font-bold text-white mb-4 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-400" />
                <span>Early Warning Indicators ({prediction.early_warnings.length})</span>
              </h3>

              {prediction.early_warnings.length === 0 ? (
                <p className="text-xs text-emerald-400 font-medium">
                  No active critical warning signals detected for this profile.
                </p>
              ) : (
                <div className="space-y-3">
                  {prediction.early_warnings.map((w, i) => (
                    <div
                      key={i}
                      className="bg-slate-900/80 p-3 rounded-xl border border-amber-500/30 text-xs text-slate-300"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold text-amber-400">{w.code}</span>
                        <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded font-mono">
                          {w.severity}
                        </span>
                      </div>
                      <p>{w.message}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Grounded Recommendations */}
            <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/60 rounded-2xl p-6 shadow-lg">
              <h3 className="text-base font-bold text-white mb-4 flex items-center gap-2">
                <Lightbulb className="w-5 h-5 text-indigo-400" />
                <span>Personalized Recommendations</span>
              </h3>

              <div className="space-y-3">
                {prediction.recommendations.map((r, i) => (
                  <div key={i} className="bg-slate-900/80 p-3 rounded-xl border border-indigo-500/30 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-indigo-300">{r.area}</span>
                      <span className="text-[10px] bg-indigo-500/20 text-indigo-400 px-1.5 py-0.5 rounded font-semibold">
                        Impact: {r.impact}
                      </span>
                    </div>
                    <p className="text-slate-300">{r.action}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
