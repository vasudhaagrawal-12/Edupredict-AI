import React from 'react';
import {
  GraduationCap,
  ShieldAlert,
  BrainCircuit,
  Sliders,
  Sparkles,
  ArrowRight,
  Database,
  Code2
} from 'lucide-react';

interface LandingPageProps {
  onStartDemo: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onStartDemo }) => {
  return (
    <div className="space-y-16 py-8 max-w-6xl mx-auto">
      {/* Hero Section */}
      <div className="text-center space-y-6">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-semibold">
          <Sparkles className="w-4 h-4" />
          <span>Production-Grade ML Student Performance & Risk Platform</span>
        </div>

        <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight bg-gradient-to-r from-white via-slate-100 to-indigo-300 bg-clip-text text-transparent">
          Predict Academic Outcomes.<br />Prevent Student Failure.
        </h1>

        <p className="text-base md:text-lg text-slate-300 max-w-3xl mx-auto leading-relaxed">
          EduPredict AI integrates dual machine learning models (Regression + Failure Risk Classification),
          SHAP explainability, non-causal what-if simulations, and grounded AI Copilot assistance for proactive educational intervention.
        </p>

        <div className="flex flex-wrap justify-center gap-4 pt-4">
          <button
            onClick={onStartDemo}
            className="flex items-center gap-2 px-8 py-3.5 bg-gradient-to-r from-indigo-600 via-indigo-500 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold text-sm rounded-xl shadow-xl shadow-indigo-600/30 transition-all hover:scale-105"
          >
            <span>Launch Live Platform Demo</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Feature Highlights Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/60 rounded-2xl p-6 shadow-lg hover:border-indigo-500/50 transition-colors">
          <div className="w-12 h-12 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 mb-4">
            <BrainCircuit className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-white mb-2">Dual Prediction Engine</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Predicts exact final exam marks (0-100) alongside failure risk probability using calibrated scikit-learn & XGBoost pipelines.
          </p>
        </div>

        <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/60 rounded-2xl p-6 shadow-lg hover:border-indigo-500/50 transition-colors">
          <div className="w-12 h-12 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400 mb-4">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-white mb-2">Explainable AI (SHAP)</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Transparent TreeExplainer and LinearExplainer attribution breaks down positive and negative feature drivers per prediction.
          </p>
        </div>

        <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/60 rounded-2xl p-6 shadow-lg hover:border-indigo-500/50 transition-colors">
          <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 mb-4">
            <Sliders className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-white mb-2">What-If Scenario Simulator</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Interactively simulate modified study hours or absences to evaluate predicted score changes under non-causal model response.
          </p>
        </div>
      </div>

      {/* Tech Stack Badges */}
      <div className="bg-slate-800/40 border border-slate-700/60 rounded-2xl p-6 text-center space-y-4">
        <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Engineering Technology Stack</span>
        <div className="flex flex-wrap justify-center items-center gap-3 text-xs font-semibold text-slate-300">
          <span className="px-3 py-1 bg-slate-900 border border-slate-700 rounded-lg flex items-center gap-1.5">
            <Code2 className="w-3.5 h-3.5 text-indigo-400" /> React 18 + TypeScript + Vite
          </span>
          <span className="px-3 py-1 bg-slate-900 border border-slate-700 rounded-lg flex items-center gap-1.5">
            <Database className="w-3.5 h-3.5 text-emerald-400" /> FastAPI + SQLAlchemy + SQLite
          </span>
          <span className="px-3 py-1 bg-slate-900 border border-slate-700 rounded-lg flex items-center gap-1.5">
            <BrainCircuit className="w-3.5 h-3.5 text-purple-400" /> Scikit-Learn + XGBoost + SHAP
          </span>
        </div>
      </div>
    </div>
  );
};
