import React, { useState } from 'react';
import { Student, PredictionResponse } from '../types';
import { ApiService } from '../services/api';
import { Bot, Send, User, Sparkles, CheckCircle2 } from 'lucide-react';

interface CopilotPageProps {
  selectedStudent: Student | null;
  predictionContext: PredictionResponse | null;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  grounded?: boolean;
}

export const CopilotPage: React.FC<CopilotPageProps> = ({
  selectedStudent,
  predictionContext,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'bot',
      text: selectedStudent
        ? `Hello! I am EduPredict AI Copilot. I am currently grounded in Student #${selectedStudent.id}'s performance records and SHAP attributions. How can I assist you?`
        : `Hello! I am EduPredict AI Copilot. Select a student profile or ask general questions about our prediction engine, SHAP attributions, or risk thresholds.`,
      grounded: !!selectedStudent,
    },
  ]);
  const [inputQuery, setInputQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputQuery.trim() || isLoading) return;

    const userText = inputQuery;
    setInputQuery('');

    const userMsg: ChatMessage = {
      id: String(Date.now()),
      sender: 'user',
      text: userText,
    };
    setMessages((prev) => [...prev, userMsg]);
    setIsLoading(true);

    try {
      const res = await ApiService.queryCopilot(userText, predictionContext ?? undefined);
      const botMsg: ChatMessage = {
        id: String(Date.now() + 1),
        sender: 'bot',
        text: res.answer,
        grounded: res.grounded_context_used,
      };
      setMessages((prev) => [...prev, botMsg]);
    } catch (err: any) {
      const errMsg: ChatMessage = {
        id: String(Date.now() + 1),
        sender: 'bot',
        text: `Copilot service error: ${err.message}`,
        grounded: false,
      };
      setMessages((prev) => [...prev, errMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const samplePrompts = [
    'Why is this student at risk?',
    'What are the main factors affecting this prediction?',
    'What should this student focus on to improve?',
    'What would happen if attendance improved?',
  ];

  return (
    <div className="space-y-6 py-4 max-w-4xl mx-auto">
      {/* Header */}
      <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/60 rounded-2xl p-6 shadow-lg flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
            <Bot className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-white">Grounded AI Copilot Assistant</h2>
            <p className="text-xs text-slate-400">
              Grounded strictly in actual predictions, SHAP attribution, and early warning indicators
            </p>
          </div>
        </div>

        {selectedStudent && (
          <span className="text-xs px-2.5 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 font-medium">
            Active Context: Student #{selectedStudent.id}
          </span>
        )}
      </div>

      {/* Suggested Quick Prompts */}
      <div className="flex flex-wrap gap-2">
        {samplePrompts.map((prompt, idx) => (
          <button
            key={idx}
            onClick={() => setInputQuery(prompt)}
            className="text-xs px-3 py-1.5 bg-slate-800/60 hover:bg-slate-700/60 border border-slate-700 rounded-xl text-slate-300 transition-colors flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>{prompt}</span>
          </button>
        ))}
      </div>

      {/* Chat Messages Container */}
      <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/60 rounded-2xl p-6 shadow-lg h-[420px] flex flex-col justify-between">
        <div className="overflow-y-auto space-y-4 pr-2">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex items-start gap-3 ${
                msg.sender === 'user' ? 'flex-row-reverse' : ''
              }`}
            >
              <div
                className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs shrink-0 ${
                  msg.sender === 'user'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-purple-600/20 border border-purple-500/30 text-purple-300'
                }`}
              >
                {msg.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div
                className={`p-4 rounded-2xl text-xs leading-relaxed max-w-[80%] ${
                  msg.sender === 'user'
                    ? 'bg-indigo-600 text-white rounded-tr-none'
                    : 'bg-slate-900/90 text-slate-200 border border-slate-700 rounded-tl-none space-y-2'
                }`}
              >
                <div className="whitespace-pre-wrap">{msg.text}</div>
                {msg.sender === 'bot' && msg.grounded && (
                  <div className="flex items-center gap-1 text-[10px] text-emerald-400 font-semibold pt-1 border-t border-slate-800">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>Grounded in system predictions &amp; SHAP results</span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Input Form */}
        <form onSubmit={handleSend} className="mt-4 flex gap-2">
          <input
            type="text"
            placeholder="Ask Copilot about risk, SHAP factors, recommendations..."
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            className="flex-1 px-4 py-2.5 bg-slate-900/90 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
          <button
            type="submit"
            disabled={isLoading || !inputQuery.trim()}
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-indigo-600/30 transition-all disabled:opacity-50 flex items-center gap-1.5"
          >
            <Send className="w-4 h-4" />
            <span>Send</span>
          </button>
        </form>
      </div>
    </div>
  );
};
