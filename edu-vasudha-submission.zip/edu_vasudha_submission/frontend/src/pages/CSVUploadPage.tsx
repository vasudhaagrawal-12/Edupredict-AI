import React from 'react';
import { DatasetUploader } from '../components/DatasetUploader';
import { FileSpreadsheet } from 'lucide-react';

export const CSVUploadPage: React.FC = () => {
  return (
    <div className="space-y-8 py-4">
      <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/60 rounded-2xl p-6 shadow-lg">
        <h2 className="text-2xl font-extrabold text-white flex items-center gap-2">
          <FileSpreadsheet className="w-7 h-7 text-indigo-400" />
          <span>Batch Dataset Upload & Validation</span>
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Validate student CSV schemas, inspect row-level error reports, and run batch ML predictions
        </p>
      </div>

      <DatasetUploader />
    </div>
  );
};
