import React, { useEffect, useState } from 'react';
import { ModelLabData } from '../types';
import { ApiService } from '../services/api';
import { ModelComparison } from '../components/ModelComparison';
import { BrainCircuit, RefreshCw } from 'lucide-react';

export const ModelLabPage: React.FC = () => {
  const [modelData, setModelData] = useState<ModelLabData | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function loadModelLab() {
      try {
        const data = await ApiService.getModelLab();
        setModelData(data);
      } catch (err) {
        console.error('Failed to load Model Lab metadata:', err);
      } finally {
        setIsLoading(false);
      }
    }
    loadModelLab();
  }, []);

  return (
    <div className="space-y-8 py-4">
      <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/60 rounded-2xl p-6 shadow-lg flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-extrabold text-white flex items-center gap-2">
            <BrainCircuit className="w-7 h-7 text-indigo-400" />
            <span>EduPredict Model Lab & ML Architecture</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Real evaluation metrics from 5 Regression and 4 Classification algorithms evaluated on held-out test data
          </p>
        </div>

        <button
          onClick={() => window.location.reload()}
          className="flex items-center gap-1.5 px-3.5 py-1.5 bg-slate-900 border border-slate-700 hover:border-slate-600 rounded-xl text-xs text-slate-300 transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh Metrics</span>
        </button>
      </div>

      {isLoading ? (
        <div className="text-center py-16 text-slate-400">Loading Model Lab evaluation metrics...</div>
      ) : modelData ? (
        <ModelComparison data={modelData} />
      ) : (
        <div className="text-center py-16 text-rose-400">Failed to load Model Lab metrics.</div>
      )}
    </div>
  );
};
