import React, { useState } from 'react';
import { Student, PredictionMode, PredictionResponse } from './types';
import { Navbar } from './components/Navbar';
import { LandingPage } from './pages/LandingPage';
import { DashboardPage } from './pages/DashboardPage';
import { StudentProfilePage } from './pages/StudentProfilePage';
import { ModelLabPage } from './pages/ModelLabPage';
import { CSVUploadPage } from './pages/CSVUploadPage';
import { CopilotPage } from './pages/CopilotPage';
import { WhatIfSimulator } from './components/WhatIfSimulator';

export const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('landing');
  const [predictionMode, setPredictionMode] = useState<PredictionMode>('performance');
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [predictionContext, setPredictionContext] = useState<PredictionResponse | null>(null);

  const handleSelectStudent = (student: Student) => {
    setSelectedStudent(student);
    setActiveTab('profile');
  };

  const sampleBaselineStudent: Student = selectedStudent || {
    school: 'GP',
    sex: 'F',
    age: 17,
    address: 'U',
    famsize: 'GT3',
    Pstatus: 'T',
    Medu: 2,
    Fedu: 2,
    Mjob: 'other',
    Fjob: 'other',
    reason: 'course',
    guardian: 'mother',
    traveltime: 1,
    studytime: 1,
    failures: 1,
    schoolsup: 'no',
    famsup: 'yes',
    paid: 'no',
    activities: 'no',
    nursery: 'yes',
    higher: 'yes',
    internet: 'yes',
    romantic: 'no',
    famrel: 3,
    freetime: 3,
    goout: 4,
    Dalc: 2,
    Walc: 3,
    health: 3,
    absences: 12,
    G1: 8,
    G2: 8,
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col justify-between">
      <div>
        <Navbar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          predictionMode={predictionMode}
          setPredictionMode={setPredictionMode}
        />

        <main className="max-w-7xl mx-auto px-4 lg:px-8 py-6">
          {activeTab === 'landing' && (
            <LandingPage onStartDemo={() => setActiveTab('dashboard')} />
          )}

          {activeTab === 'dashboard' && (
            <DashboardPage onSelectStudent={handleSelectStudent} />
          )}

          {activeTab === 'profile' && (
            <StudentProfilePage
              selectedStudent={selectedStudent}
              predictionMode={predictionMode}
            />
          )}

          {activeTab === 'simulator' && (
            <div className="py-4 space-y-4">
              <div className="bg-slate-800/50 border border-slate-700/60 rounded-2xl p-4 flex items-center justify-between text-xs">
                <span className="text-slate-300">
                  Simulating profile: <span className="font-bold text-indigo-400">{selectedStudent ? `Student #${selectedStudent.id}` : 'Default Sample Profile'}</span>
                </span>
                <span className="text-slate-400 uppercase font-semibold">Mode: {predictionMode}</span>
              </div>
              <WhatIfSimulator
                baselineStudent={sampleBaselineStudent}
                predictionMode={predictionMode}
              />
            </div>
          )}

          {activeTab === 'model-lab' && <ModelLabPage />}

          {activeTab === 'csv-upload' && <CSVUploadPage />}

          {activeTab === 'copilot' && (
            <CopilotPage
              selectedStudent={selectedStudent}
              predictionContext={predictionContext}
            />
          )}
        </main>
      </div>

      {/* Footer */}
      <footer className="border-t border-slate-800 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>© 2026 EduPredict AI • Intelligent Student Performance Prediction &amp; Early Warning System</p>
          <div className="flex items-center gap-4 text-slate-400">
            <button onClick={() => setActiveTab('model-lab')} className="hover:text-white transition-colors">
              Model Lab
            </button>
            <button onClick={() => setActiveTab('csv-upload')} className="hover:text-white transition-colors">
              CSV Validation
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};
