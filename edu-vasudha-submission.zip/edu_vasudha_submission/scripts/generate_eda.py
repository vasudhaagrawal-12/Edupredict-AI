"""
EDA Generator Script for EduPredict AI
Computes real dataset statistics and exports data/processed/eda_summary.json.
"""

import os
import json
import pandas as pd
import numpy as np

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH = os.path.join(REPO_ROOT, "data", "raw", "student-mat.csv")
OUTPUT_PATH = os.path.join(REPO_ROOT, "data", "processed", "eda_summary.json")

def generate_eda():
    if not os.path.exists(DATA_PATH):
        raise FileNotFoundError(f"Raw data file not found at {DATA_PATH}")

    try:
        df = pd.read_csv(DATA_PATH, sep=";")
        if len(df.columns) < 5:
            df = pd.read_csv(DATA_PATH, sep=",")
    except Exception as e:
        raise ValueError(f"Failed to load dataset for EDA: {e}")

    # Derived targets
    df["final_marks"] = df["G3"] * 5.0
    df["at_risk"] = (df["G3"] < 10).astype(int)

    total_students = len(df)
    at_risk_count = int(df["at_risk"].sum())
    passing_count = total_students - at_risk_count

    # Score distribution
    score_dist = {
        "mean_final_marks": float(round(df["final_marks"].mean(), 2)),
        "median_final_marks": float(round(df["final_marks"].median(), 2)),
        "std_final_marks": float(round(df["final_marks"].std(), 2)),
        "min_final_marks": float(df["final_marks"].min()),
        "max_final_marks": float(df["final_marks"].max()),
    }

    # Pass vs Risk Distribution
    risk_dist = {
        "passing_students": passing_count,
        "at_risk_students": at_risk_count,
        "pass_rate_pct": float(round((passing_count / total_students) * 100, 2)),
        "risk_rate_pct": float(round((at_risk_count / total_students) * 100, 2))
    }

    # Feature Correlations with Final Marks
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    correlations = df[numeric_cols].corr()["final_marks"].drop(["final_marks", "G3", "at_risk"]).round(4).to_dict()

    # Absences vs Risk
    absence_summary = {
        "mean_absences_passing": float(round(df[df["at_risk"] == 0]["absences"].mean(), 2)),
        "mean_absences_at_risk": float(round(df[df["at_risk"] == 1]["absences"].mean(), 2)),
    }

    # Failures vs Risk
    failure_risk_map = df.groupby("failures")["at_risk"].mean().round(4).to_dict()
    failure_risk_map_str = {str(k): float(v) for k, v in failure_risk_map.items()}

    # Study Time vs Mean Marks
    study_marks_map = df.groupby("studytime")["final_marks"].mean().round(2).to_dict()
    study_marks_map_str = {str(k): float(v) for k, v in study_marks_map.items()}

    eda_data = {
        "dataset_name": "UCI Student Performance (student-mat.csv)",
        "total_students": total_students,
        "score_distribution": score_dist,
        "risk_distribution": risk_dist,
        "feature_correlations": correlations,
        "absence_summary": absence_summary,
        "failure_risk_rate": failure_risk_map_str,
        "studytime_mean_marks": study_marks_map_str,
    }

    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(eda_data, f, indent=2)

    print(f"EDA Summary successfully written to {OUTPUT_PATH}")
    return eda_data

if __name__ == "__main__":
    generate_eda()
