"""
Database Seeding Script for EduPredict AI
Populates initial database records from raw student dataset.
"""

import os
import pandas as pd
from backend.app.core.database import SessionLocal, engine, Base
from backend.app.models.orm import StudentDB, PredictionDB, ExplanationDB
from backend.app.ml.inference_engine import inference_engine
from backend.app.schemas.contracts import StudentBase

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CSV_PATH = os.path.join(REPO_ROOT, "data", "raw", "student-mat.csv")

def seed_database():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    
    if db.query(StudentDB).count() > 0:
        print("Database already contains student records. Skipping seed.")
        db.close()
        return

    if not os.path.exists(CSV_PATH):
        print(f"Cannot seed database: CSV file missing at {CSV_PATH}")
        db.close()
        return

    try:
        df = pd.read_csv(CSV_PATH, sep=";")
        if len(df.columns) < 5:
            df = pd.read_csv(CSV_PATH, sep=",")
    except Exception as e:
        print(f"Failed to read CSV for seeding: {e}")
        db.close()
        return

    # Seed top 15 records
    sample_df = df.head(15)
    print(f"Seeding database with {len(sample_df)} student profiles...")

    for _, row in sample_df.iterrows():
        student_data = {
            "school": str(row.get("school", "GP")),
            "sex": str(row.get("sex", "F")),
            "age": int(row.get("age", 17)),
            "address": str(row.get("address", "U")),
            "famsize": str(row.get("famsize", "GT3")),
            "Pstatus": str(row.get("Pstatus", "T")),
            "Medu": int(row.get("Medu", 2)),
            "Fedu": int(row.get("Fedu", 2)),
            "Mjob": str(row.get("Mjob", "other")),
            "Fjob": str(row.get("Fjob", "other")),
            "reason": str(row.get("reason", "course")),
            "guardian": str(row.get("guardian", "mother")),
            "traveltime": int(row.get("traveltime", 1)),
            "studytime": int(row.get("studytime", 2)),
            "failures": int(row.get("failures", 0)),
            "schoolsup": str(row.get("schoolsup", "no")),
            "famsup": str(row.get("famsup", "yes")),
            "paid": str(row.get("paid", "no")),
            "activities": str(row.get("activities", "no")),
            "nursery": str(row.get("nursery", "yes")),
            "higher": str(row.get("higher", "yes")),
            "internet": str(row.get("internet", "yes")),
            "romantic": str(row.get("romantic", "no")),
            "famrel": int(row.get("famrel", 4)),
            "freetime": int(row.get("freetime", 3)),
            "goout": int(row.get("goout", 3)),
            "Dalc": int(row.get("Dalc", 1)),
            "Walc": int(row.get("Walc", 1)),
            "health": int(row.get("health", 4)),
            "absences": int(row.get("absences", 4)),
            "G1": int(row.get("G1", 10)),
            "G2": int(row.get("G2", 10)),
            "G3": int(row.get("G3", 10)),
        }

        db_student = StudentDB(**student_data)
        db.add(db_student)
        db.commit()
        db.refresh(db_student)

        # Run initial prediction for seed student
        student_base = StudentBase(**{k: v for k, v in student_data.items() if k != "G3"})
        pred_res = inference_engine.predict(student_base, mode="performance")

        db_pred = PredictionDB(
            student_id=db_student.id,
            prediction_mode="performance",
            predicted_score=pred_res.predicted_score,
            pass_probability=pred_res.pass_probability,
            risk_probability=pred_res.risk_probability,
            risk_score=pred_res.risk_score,
            risk_category=pred_res.risk_category,
            is_anomaly=pred_res.is_anomaly
        )
        db.add(db_pred)
        db.commit()
        db.refresh(db_pred)

        db_exp = ExplanationDB(
            prediction_id=db_pred.id,
            top_positives=[item.model_dump() for item in pred_res.top_positive_contributors],
            top_negatives=[item.model_dump() for item in pred_res.top_negative_contributors],
            early_warnings=[item.model_dump() for item in pred_res.early_warnings],
            recommendations=[item.model_dump() for item in pred_res.recommendations]
        )
        db.add(db_exp)
        db.commit()

    print("Database seeding completed successfully!")
    db.close()

if __name__ == "__main__":
    seed_database()
