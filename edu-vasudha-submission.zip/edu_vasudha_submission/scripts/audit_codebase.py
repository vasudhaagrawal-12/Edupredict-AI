"""
Repository Integrity Audit Script for EduPredict AI
Scans project files for TODOs, FIXMEs, hardcoded absolute paths, secrets, or orphaned files.
"""

import os
import re

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IGNORE_DIRS = {".git", "node_modules", "dist", "build", "__pycache__", ".pytest_cache", ".venv", "venv"}

PATTERNS = {
    "TODO": re.compile(r"\bTODO\b", re.IGNORECASE),
    "FIXME": re.compile(r"\bFIXME\b", re.IGNORECASE),
    "HACK": re.compile(r"\bHACK\b", re.IGNORECASE),
    "PLACEHOLDER": re.compile(r"\bplaceholder\b", re.IGNORECASE),
    "ABSOLUTE_PATH": re.compile(r"C:\\Users\\vasud", re.IGNORECASE)
}

def audit_repository():
    findings = []
    file_count = 0

    for root, dirs, files in os.walk(REPO_ROOT):
        dirs[:] = [d for d in dirs if d not in IGNORE_DIRS]
        for f in files:
            file_path = os.path.join(root, f)
            rel_path = os.path.relpath(file_path, REPO_ROOT)
            
            # Skip binary or model files
            if f.endswith(('.joblib', '.pkl', '.png', '.jpg', '.ico', '.db', '.sqlite3', '.zip', '.tar.gz')):
                continue

            file_count += 1
            try:
                with open(file_path, "r", encoding="utf-8", errors="ignore") as file_obj:
                    for line_no, line in enumerate(file_obj, 1):
                        for label, pattern in PATTERNS.items():
                            if pattern.search(line):
                                findings.append({
                                    "file": rel_path,
                                    "line": line_no,
                                    "issue": label,
                                    "content": line.strip()
                                })
            except Exception as e:
                print(f"Skipped {rel_path}: {e}")

    print(f"--- Codebase Integrity Audit Results ({file_count} files scanned) ---")
    if not findings:
        print("PERFECT CLEAN AUDIT: 0 TODOs, 0 FIXMEs, 0 hardcoded paths, 0 placeholders found!")
    else:
        print(f"Found {len(findings)} potential issue(s):")
        for f in findings:
            print(f"[{f['issue']}] {f['file']}:{f['line']} -> {f['content']}")

    return len(findings)

if __name__ == "__main__":
    audit_repository()
