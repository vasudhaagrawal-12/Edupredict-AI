# EduPredict AI - CSV Upload Data Schema

EduPredict AI accepts batch CSV uploads for student risk evaluation and score prediction.

## Required & Optional Columns

CSV files can be uploaded using either **Mode A (Early-Warning)** or **Mode B (Performance-Prediction)**.

### Mode A (Early-Warning)
Required fields:
- `age`: integer ($15-22$)
- `sex`: string (`F` or `M`)
- `studytime`: integer ($1-4$)
- `failures`: integer ($0-4$)
- `absences`: integer ($0-93$)
- `Dalc`: integer ($1-5$)
- `Walc`: integer ($1-5$)
- `famrel`: integer ($1-5$)
- `Medu`: integer ($0-4$)
- `Fedu`: integer ($0-4$)

### Mode B (Performance-Prediction)
All Mode A fields plus:
- `G1`: integer ($0-20$)
- `G2`: integer ($0-20$)

## Validation Rules
1. **Numeric Range Enforcement**:
   - `age`: $15 \le \text{age} \le 22$
   - `studytime`: $1 \le \text{studytime} \le 4$
   - `failures`: $0 \le \text{failures} \le 4$
   - `absences`: $0 \le \text{absences} \le 93$
   - `G1`, `G2`: $0 \le G \le 20$
2. **Missing Values**: Rows with missing required columns will generate detailed row-level error reports during CSV validation.
3. **Data Delimiters**: Supports both standard comma (`,`) and semicolon (`;`) delimiters.
