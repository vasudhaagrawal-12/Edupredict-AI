"""
Backend Configuration Module for EduPredict AI
Centralized settings management using pydantic-settings.
"""

import os
from pydantic import ConfigDict
from pydantic_settings import BaseSettings

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class Settings(BaseSettings):
    PROJECT_NAME: str = "EduPredict AI"
    VERSION: str = "1.0.0"
    API_PREFIX: str = "/api"
    
    # Environment & Host
    ENVIRONMENT: str = "development"
    DEBUG: bool = True
    PORT: int = 8000
    HOST: str = "0.0.0.0"
    
    # Database URL (SQLite default, PostgreSQL supported)
    DATABASE_URL: str = f"sqlite:///{os.path.join(REPO_ROOT, 'edupredict.db')}"
    
    # CORS Allowed Origins
    CORS_ORIGINS: list = [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:3000",
        "http://localhost:80",
        "http://localhost"
    ]
    
    # Paths
    REPO_ROOT: str = REPO_ROOT
    MODEL_ARTIFACTS_DIR: str = os.path.join(REPO_ROOT, "ml", "artifacts")
    DATA_DIR: str = os.path.join(REPO_ROOT, "data")
    
    # Optional LLM API Keys
    OPENAI_API_KEY: str = ""
    GEMINI_API_KEY: str = ""

    model_config = ConfigDict(env_file=".env", extra="ignore")

settings = Settings()
