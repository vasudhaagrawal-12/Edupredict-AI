"""
FastAPI Route Handlers for EduPredict AI
Thin HTTP endpoints delegating business logic to services and repositories.
"""

import os
import json
import io
import pandas as pd
from typing import List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Query
from sqlalchemy.orm import Session

from backend.app.core.database import get_db
from backend.app.core.config import settings
from backend.app.schemas.contracts import (
    StudentCreate, StudentResponse, PredictionRequest, PredictionResponse,
    SimulationRequest, SimulationResponse, CopilotRequest, CopilotResponse,
    CSVValidationResponse, DatasetValidationError
)
from backend.app.repositories.data_access import (
    create_student, get_student_by_id, get_all_students,
    create_prediction_record, record_dataset_upload
)
from backend.app.ml.inference_engine import inference_engine
from backend.app.services.copilot_service import process_copilot_query

router = APIRouter()

@router.get("/health", tags=["Health"])
def health_check():
    return {
        "status": "healthy",
        "service": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "models_loaded": list(inference_engine.models.keys())
    }

@router.post("/predictions", response_model=PredictionResponse, tags=["Predictions"])
def predict_student_performance(req: PredictionRequest, db: Session = Depends(get_db)):
    try:
        prediction_res = inference_engine.predict(req.features, mode=req.prediction_mode)
        
        # Save to database if student_id provided or create student
        if req.student_id:
            create_prediction_record(db, req.student_id, prediction_res)
        return prediction_res
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction inference error: {str(e)}")

@router.get("/students", response_model=List[StudentResponse], tags=["Students"])
def list_students(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    return get_all_students(db, skip=skip, limit=limit)

@router.get("/students/{student_id}", response_model=StudentResponse, tags=["Students"])
def get_student(student_id: int, db: Session = Depends(get_db)):
    student = get_student_by_id(db, student_id)
    if not student:
        raise HTTPException(status_code=404, detail=f"Student with ID {student_id} not found.")
    return student

@router.post("/students", response_model=StudentResponse, tags=["Students"])
def add_student(student: StudentCreate, db: Session = Depends(get_db)):
    return create_student(db, student)

@router.post("/simulations", response_model=SimulationResponse, tags=["Simulations"])
def run_what_if_simulation(req: SimulationRequest):
    base_res = inference_engine.predict(req.baseline_features, mode=req.prediction_mode)
    sim_res = inference_engine.predict(req.modified_features, mode=req.prediction_mode)

    score_delta = round(sim_res.predicted_score - base_res.predicted_score, 1)
    risk_delta = round(sim_res.risk_score - base_res.risk_score, 1)

    disclaimer = (
        "This simulation shows how the trained ML model responds to altered inputs. "
        "It does not establish causal proof that modifying this factor will guarantee the predicted outcome."
    )

    return SimulationResponse(
        baseline_predicted_score=base_res.predicted_score,
        simulated_predicted_score=sim_res.predicted_score,
        score_delta=score_delta,
        baseline_risk_score=base_res.risk_score,
        simulated_risk_score=sim_res.risk_score,
        risk_score_delta=risk_delta,
        baseline_risk_category=base_res.risk_category,
        simulated_risk_category=sim_res.risk_category,
        disclaimer=disclaimer
    )

@router.post("/datasets/validate", response_model=CSVValidationResponse, tags=["Datasets"])
async def validate_csv_dataset(file: UploadFile = File(...)):
    if not file.filename.endswith(".csv"):
        raise HTTPException(status_code=400, detail="Uploaded file must be a .csv file.")

    contents = await file.read()
    try:
        df = pd.read_csv(io.BytesIO(contents), sep=";")
        if len(df.columns) < 5:
            df = pd.read_csv(io.BytesIO(contents), sep=",")
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid CSV structure: {str(e)}")

    total_rows = len(df)
    errors = []
    valid_rows = 0

    required_range_checks = {
        "age": (15, 22),
        "studytime": (1, 4),
        "failures": (0, 4),
        "absences": (0, 93),
        "famrel": (1, 5),
        "freetime": (1, 5),
        "goout": (1, 5),
        "Dalc": (1, 5),
        "Walc": (1, 5),
        "health": (1, 5)
    }

    for idx, row in df.iterrows():
        row_valid = True
        for col, (min_v, max_v) in required_range_checks.items():
            if col in df.columns:
                try:
                    val = float(row[col])
                    if val < min_v or val > max_v:
                        errors.append(DatasetValidationError(
                            row_index=idx + 1,
                            column=col,
                            error_message=f"Value {val} out of bounds [{min_v}, {max_v}]"
                        ))
                        row_valid = False
                except Exception:
                    errors.append(DatasetValidationError(
                        row_index=idx + 1,
                        column=col,
                        error_message=f"Invalid non-numeric value '{row[col]}'"
                    ))
                    row_valid = False
        if row_valid:
            valid_rows += 1

    sample_records = df.head(5).to_dict(orient="records")

    return CSVValidationResponse(
        filename=file.filename,
        total_rows=total_rows,
        valid_rows=valid_rows,
        invalid_rows=total_rows - valid_rows,
        errors=errors[:20],  # Return first 20 errors
        sample_preview=sample_records
    )

@router.post("/datasets/upload", tags=["Datasets"])
async def upload_csv_dataset(file: UploadFile = File(...), db: Session = Depends(get_db)):
    val_res = await validate_csv_dataset(file)
    record_dataset_upload(db, val_res.filename, val_res.total_rows, val_res.valid_rows, val_res.invalid_rows)
    return {
        "message": f"Successfully processed {val_res.filename}",
        "summary": val_res
    }

@router.get("/models", tags=["Model Lab"])
def get_model_metadata():
    reg_meta_path = os.path.join(settings.MODEL_ARTIFACTS_DIR, "regression", "metadata.json")
    cls_meta_path = os.path.join(settings.MODEL_ARTIFACTS_DIR, "classification", "metadata.json")
    reg_metrics_path = os.path.join(settings.MODEL_ARTIFACTS_DIR, "regression", "metrics.json")
    cls_metrics_path = os.path.join(settings.MODEL_ARTIFACTS_DIR, "classification", "metrics.json")

    reg_meta = json.load(open(reg_meta_path)) if os.path.exists(reg_meta_path) else {}
    cls_meta = json.load(open(cls_meta_path)) if os.path.exists(cls_meta_path) else {}
    reg_metrics = json.load(open(reg_metrics_path)) if os.path.exists(reg_metrics_path) else {}
    cls_metrics = json.load(open(cls_metrics_path)) if os.path.exists(cls_metrics_path) else {}

    return {
        "regression": {
            "selected_model": reg_meta.get("model_name", "Random Forest Regressor"),
            "metrics": reg_metrics,
            "all_evaluations": reg_meta.get("evaluations_comparison", {})
        },
        "classification": {
            "selected_model": cls_meta.get("model_name", "Logistic Regression"),
            "metrics": cls_metrics,
            "all_evaluations": cls_meta.get("evaluations_comparison", {})
        }
    }

@router.post("/copilot", response_model=CopilotResponse, tags=["AI Copilot"])
def query_copilot(req: CopilotRequest):
    return process_copilot_query(req)

@router.get("/eda", tags=["Analytics"])
def get_eda_summary():
    eda_path = os.path.join(settings.DATA_DIR, "processed", "eda_summary.json")
    if not os.path.exists(eda_path):
        raise HTTPException(status_code=444, detail="EDA summary report not yet generated.")
    return json.load(open(eda_path))
