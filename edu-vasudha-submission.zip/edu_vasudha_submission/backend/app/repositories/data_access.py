"""
Data Access Repository Pattern for EduPredict AI
Handles all database operations for students, predictions, and uploads.
"""

from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session
from backend.app.models.orm import StudentDB, PredictionDB, ExplanationDB, DatasetUploadDB
from backend.app.schemas.contracts import StudentCreate, PredictionResponse

def create_student(db: Session, student_data: StudentCreate) -> StudentDB:
    student_dict = student_data.model_dump()
    db_student = StudentDB(**student_dict)
    db.add(db_student)
    db.commit()
    db.refresh(db_student)
    return db_student

def get_student_by_id(db: Session, student_id: int) -> Optional[StudentDB]:
    return db.query(StudentDB).filter(StudentDB.id == student_id).first()

def get_all_students(db: Session, skip: int = 0, limit: int = 100) -> List[StudentDB]:
    return db.query(StudentDB).offset(skip).limit(limit).all()

def create_prediction_record(
    db: Session,
    student_id: Optional[int],
    pred_res: PredictionResponse
) -> PredictionDB:
    db_pred = PredictionDB(
        student_id=student_id,
        prediction_mode=pred_res.prediction_mode,
        predicted_score=pred_res.predicted_score,
        pass_probability=pred_res.pass_probability,
        risk_probability=pred_res.risk_probability,
        risk_score=pred_res.risk_score,
        risk_category=pred_res.risk_category,
        is_anomaly=pred_res.is_anomaly
    )
    db.add(db_pred)
    db.commit()
    db.refresh(db_pred)

    db_exp = ExplanationDB(
        prediction_id=db_pred.id,
        top_positives=[item.model_dump() for item in pred_res.top_positive_contributors],
        top_negatives=[item.model_dump() for item in pred_res.top_negative_contributors],
        early_warnings=[item.model_dump() for item in pred_res.early_warnings],
        recommendations=[item.model_dump() for item in pred_res.recommendations]
    )
    db.add(db_exp)
    db.commit()

    return db_pred

def record_dataset_upload(
    db: Session,
    filename: str,
    total_rows: int,
    valid_rows: int,
    invalid_rows: int
) -> DatasetUploadDB:
    status = "SUCCESS" if invalid_rows == 0 else ("PARTIAL" if valid_rows > 0 else "FAILED")
    db_upload = DatasetUploadDB(
        filename=filename,
        row_count=total_rows,
        valid_count=valid_rows,
        error_count=invalid_rows,
        status=status
    )
    db.add(db_upload)
    db.commit()
    db.refresh(db_upload)
    return db_upload
