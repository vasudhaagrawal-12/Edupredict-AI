"""
Production ML Inference Engine for EduPredict AI
Loads persisted joblib models, executes dual predictions, SHAP, and risk calculation.
"""

import os
import joblib
import pandas as pd
import numpy as np

from backend.app.core.config import settings
from backend.app.schemas.contracts import StudentBase, PredictionResponse, FeatureContribution, EarlyWarningSignal, Recommendation
from backend.app.services.risk_engine import calculate_risk_score
from ml.features.engineer import engineer_features
from ml.explainability.shap_explainer import explain_prediction
from ml.anomaly.detector import AnomalyDetector

class MLInferenceEngine:
    def __init__(self):
        self.models = {}
        self.anomaly_detector = AnomalyDetector()
        self.load_models()

    def load_models(self):
        reg_path = os.path.join(settings.MODEL_ARTIFACTS_DIR, "regression", "model.joblib")
        cls_path = os.path.join(settings.MODEL_ARTIFACTS_DIR, "classification", "model.joblib")

        if os.path.exists(reg_path):
            self.models["regression"] = joblib.load(reg_path)
            print(f"Loaded regression model from {reg_path}")

        if os.path.exists(cls_path):
            self.models["classification"] = joblib.load(cls_path)
            print(f"Loaded classification model from {cls_path}")

        # Fit simple anomaly detector baseline if raw dataset exists
        raw_csv = os.path.join(settings.DATA_DIR, "raw", "student-mat.csv")
        if os.path.exists(raw_csv):
            try:
                df = pd.read_csv(raw_csv, sep=";")
                if len(df.columns) < 5:
                    df = pd.read_csv(raw_csv, sep=",")
                self.anomaly_detector.fit(df)
            except Exception as e:
                print(f"Anomaly detector initialization notice: {e}")

    def predict(self, student_input: StudentBase, mode: str = "performance") -> PredictionResponse:
        input_dict = student_input.model_dump()
        df = pd.DataFrame([input_dict])

        # Engineer features without target leakage
        df_engineered = engineer_features(df, mode=mode)
        
        # 1. Regression Prediction (Predicted Score 0-100)
        if "regression" in self.models:
            raw_score = float(self.models["regression"].predict(df_engineered)[0])
            predicted_score = float(round(np.clip(raw_score, 0.0, 100.0), 1))
        else:
            # Deterministic linear fallback if binary missing
            g1 = input_dict.get("G1", 10) or 10
            g2 = input_dict.get("G2", 10) or 10
            predicted_score = float(round((g1 * 2.5 + g2 * 2.5), 1))

        # 2. Classification Prediction (Pass vs Risk Probability)
        if "classification" in self.models:
            probs = self.models["classification"].predict_proba(df_engineered)[0]
            # Class 1 is 'at_risk'
            risk_prob = float(probs[1]) if len(probs) > 1 else float(probs[0])
            pass_prob = float(1.0 - risk_prob)
        else:
            risk_prob = 0.2 if predicted_score >= 50 else 0.7
            pass_prob = 1.0 - risk_prob

        # 3. Risk Engine Score & Warning Signals
        risk_res = calculate_risk_score(risk_prob, input_dict)

        # 4. SHAP Feature Attribution
        shap_res = {}
        if "regression" in self.models:
            shap_res = explain_prediction(self.models["regression"], df_engineered)

        # 5. Anomaly Detection
        anomaly_res = self.anomaly_detector.predict_anomaly(df)

        pos_contribs = [FeatureContribution(**item) for item in shap_res.get("top_positive_contributors", [])]
        neg_contribs = [FeatureContribution(**item) for item in shap_res.get("top_negative_contributors", [])]
        warnings = [EarlyWarningSignal(**item) for item in risk_res.get("early_warnings", [])]
        recs = [Recommendation(**item) for item in risk_res.get("recommendations", [])]

        return PredictionResponse(
            prediction_mode=mode,
            predicted_score=predicted_score,
            pass_probability=round(pass_prob, 4),
            risk_probability=round(risk_prob, 4),
            risk_score=risk_res["risk_score"],
            risk_category=risk_res["risk_category"],
            is_anomaly=anomaly_res["is_anomaly"],
            anomaly_description=anomaly_res["description"],
            top_positive_contributors=pos_contribs,
            top_negative_contributors=neg_contribs,
            early_warnings=warnings,
            recommendations=recs
        )

# Global inference engine singleton
inference_engine = MLInferenceEngine()
