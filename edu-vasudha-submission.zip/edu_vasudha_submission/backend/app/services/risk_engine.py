"""
Academic Risk Engine & Early Warning Detector
EduPredict AI Service Layer
"""

from typing import Dict, List, Any

# Centralized Risk Threshold Configurations
RISK_THRESHOLDS = {
    "LOW_MAX": 24.99,
    "MODERATE_MAX": 49.99,
    "HIGH_MAX": 74.99,
    "CRITICAL_MIN": 75.0
}

def calculate_risk_score(calibrated_prob: float, input_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Calculates academic risk score using calibrated model probability P(Risk) * 100 as baseline.
    
    Args:
        calibrated_prob: Calibrated model risk probability (0.0 to 1.0)
        input_data: Dict of student features
        
    Returns:
        Dict with risk_score (0-100), risk_category, early_warnings list, and recommendations list.
    """
    # Baseline Risk Score: Calibrated P(Risk) * 100
    raw_score = float(calibrated_prob * 100.0)
    risk_score = float(round(np.clip(raw_score, 0.0, 100.0), 1)) if 'np' in globals() else float(round(max(0.0, min(100.0, raw_score)), 1))

    # Categorization
    if risk_score <= RISK_THRESHOLDS["LOW_MAX"]:
        category = "LOW"
    elif risk_score <= RISK_THRESHOLDS["MODERATE_MAX"]:
        category = "MODERATE"
    elif risk_score <= RISK_THRESHOLDS["HIGH_MAX"]:
        category = "HIGH"
    else:
        category = "CRITICAL"

    # Early Warning Signals Detection
    warnings = []
    absences = float(input_data.get("absences", 0))
    failures = float(input_data.get("failures", 0))
    dalc = float(input_data.get("Dalc", 1))
    walc = float(input_data.get("Walc", 1))
    g1 = input_data.get("G1")
    g2 = input_data.get("G2")

    if absences >= 15:
        warnings.append({
            "code": "CRITICAL_ABSENCE",
            "severity": "HIGH",
            "message": f"High absence record: Student has accumulated {int(absences)} absences."
        })

    if failures > 0:
        warnings.append({
            "code": "PRIOR_FAILURES",
            "severity": "HIGH" if failures >= 2 else "MODERATE",
            "message": f"Historical academic vulnerability: Student has {int(failures)} prior course failure(s)."
        })

    if (dalc + walc) >= 7:
        warnings.append({
            "code": "HIGH_ALCOHOL_INTAKE",
            "severity": "MODERATE",
            "message": "High alcohol consumption index detected, impacting focus and attendance."
        })

    if g1 is not None and g2 is not None:
        delta = float(g2) - float(g1)
        if delta <= -3:
            warnings.append({
                "code": "DECLINING_TREND",
                "severity": "HIGH",
                "message": f"Declining term trajectory: Assessment score dropped by {abs(int(delta))} points between G1 ({g1}) and G2 ({g2})."
            })

    # Grounded Personalized Recommendations
    recommendations = []
    if absences >= 10:
        recommendations.append({
            "area": "Attendance & Engagement",
            "action": "Prioritize class attendance. Reducing absences below 8 days will significantly lower model-derived risk.",
            "impact": "High"
        })

    studytime = float(input_data.get("studytime", 2))
    if studytime <= 2:
        recommendations.append({
            "area": "Study Habit",
            "action": "Increase weekly dedicated study time from <5 hours to 5-10 hours per week.",
            "impact": "High"
        })

    if failures > 0:
        recommendations.append({
            "area": "Academic Tutoring",
            "action": "Schedule regular academic tutoring sessions for foundational subject mastery.",
            "impact": "Medium"
        })

    if not recommendations:
        recommendations.append({
            "area": "Academic Maintenance",
            "action": "Maintain current study consistency and active class participation.",
            "impact": "Positive"
        })

    return {
        "risk_score": risk_score,
        "risk_category": category,
        "early_warnings": warnings,
        "recommendations": recommendations,
        "methodology": "Calibrated Model Probability P(Risk) * 100 Baseline"
    }
