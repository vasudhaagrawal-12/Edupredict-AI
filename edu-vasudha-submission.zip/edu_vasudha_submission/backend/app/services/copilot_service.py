"""
Grounded AI Copilot Service for EduPredict AI
Provides contextual answers grounded in actual student data, SHAP features, and risk indicators.
"""

from typing import Dict, Any, Optional
from backend.app.schemas.contracts import CopilotRequest, CopilotResponse, PredictionResponse

def process_copilot_query(request: CopilotRequest) -> CopilotResponse:
    """
    Processes user queries using deterministic natural language generation grounded strictly in application context.
    """
    query = request.query.lower()
    ctx: Optional[PredictionResponse] = request.prediction_context

    if ctx is None:
        answer = (
            "I am EduPredict AI Copilot. To assist you with student-specific analysis, "
            "please select or predict a student profile first. Currently, I can answer general questions "
            "about our 5 regression and 4 classification models, SHAP explainability, and risk thresholds."
        )
        return CopilotResponse(query=request.query, answer=answer, grounded_context_used=False)

    # Contextual Grounded Synthesis
    score = ctx.predicted_score
    category = ctx.risk_category
    risk_pct = round(ctx.risk_probability * 100, 1)
    pass_pct = round(ctx.pass_probability * 100, 1)
    
    top_pos = [item.feature for item in ctx.top_positive_contributors[:3]]
    top_neg = [item.feature for item in ctx.top_negative_contributors[:3]]

    pos_str = ", ".join(top_pos) if top_pos else "study habits and family support"
    neg_str = ", ".join(top_neg) if top_neg else "absences and prior course failures"

    if "why" in query and ("risk" in query or "fail" in query):
        answer = (
            f"This student is currently categorized at **{category}** academic risk (Risk Score: {ctx.risk_score}/100, "
            f"Failure Probability: {risk_pct}%).\n\n"
            f"According to our SHAP feature attribution analysis, the primary factors increasing risk are: **{neg_str}**. "
            f"Conversely, positive stabilizing factors include: **{pos_str}**."
        )

    elif "what-if" in query or "happen" in query or "improve" in query or "attendance" in query:
        answer = (
            f"Based on our trained machine learning model, improving class attendance and reducing absences "
            f"has the highest SHAP feature attribution for reducing failure risk. "
            f"You can use our interactive **What-If Simulator** tab to adjust attendance and study time sliders "
            f"and observe the exact predicted score delta."
        )

    elif "focus" in query or "recommend" in query or "should" in query:
        recs_str = "\n".join([f"- **{r.area}**: {r.action}" for r in ctx.recommendations])
        answer = (
            f"Key targeted recommendations for this student:\n\n{recs_str}\n\n"
            f"Implementing these interventions directly addresses the top negative SHAP factors."
        )

    else:
        answer = (
            f"Summary for Student:\n"
            f"- **Predicted Final Mark**: {score} / 100\n"
            f"- **Pass Probability**: {pass_pct}%\n"
            f"- **Risk Level**: {category} ({risk_pct}% failure probability)\n"
            f"- **Top Positive Factors**: {pos_str}\n"
            f"- **Top Negative Factors**: {neg_str}\n"
            f"Let me know if you would like specific guidance on risk mitigation or what-if scenario simulations."
        )

    return CopilotResponse(
        query=request.query,
        answer=answer,
        grounded_context_used=True
    )
