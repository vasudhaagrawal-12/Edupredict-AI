"""
Pydantic v2 API Data Contracts for EduPredict AI
"""

from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field, ConfigDict

class StudentBase(BaseModel):
    school: str = Field("GP", description="School code")
    sex: str = Field("F", description="Gender ('F' or 'M')")
    age: int = Field(17, ge=15, le=22, description="Student age")
    address: str = Field("U", description="Home address ('U' or 'R')")
    famsize: str = Field("GT3", description="Family size ('GT3' or 'LE3')")
    Pstatus: str = Field("T", description="Parent status ('T' or 'A')")
    Medu: int = Field(2, ge=0, le=4, description="Mother education level")
    Fedu: int = Field(2, ge=0, le=4, description="Father education level")
    Mjob: str = Field("other", description="Mother job")
    Fjob: str = Field("other", description="Father job")
    reason: str = Field("course", description="Reason for school choice")
    guardian: str = Field("mother", description="Guardian")
    traveltime: int = Field(1, ge=1, le=4, description="Travel time level")
    studytime: int = Field(2, ge=1, le=4, description="Weekly study time level")
    failures: int = Field(0, ge=0, le=4, description="Past class failures")
    schoolsup: str = Field("no", description="Educational support")
    famsup: str = Field("yes", description="Family support")
    paid: str = Field("no", description="Paid classes")
    activities: str = Field("no", description="Extracurricular activities")
    nursery: str = Field("yes", description="Nursery school")
    higher: str = Field("yes", description="Higher education desire")
    internet: str = Field("yes", description="Internet access")
    romantic: str = Field("no", description="Romantic relationship")
    famrel: int = Field(4, ge=1, le=5, description="Family relationship quality")
    freetime: int = Field(3, ge=1, le=5, description="Free time after school")
    goout: int = Field(3, ge=1, le=5, description="Socializing frequency")
    Dalc: int = Field(1, ge=1, le=5, description="Workday alcohol intake")
    Walc: int = Field(1, ge=1, le=5, description="Weekend alcohol intake")
    health: int = Field(4, ge=1, le=5, description="Health status")
    absences: int = Field(4, ge=0, le=93, description="Absence count")
    G1: Optional[int] = Field(None, ge=0, le=20, description="Period 1 score (Mode B only)")
    G2: Optional[int] = Field(None, ge=0, le=20, description="Period 2 score (Mode B only)")

class StudentCreate(StudentBase):
    pass

class StudentResponse(StudentBase):
    id: int
    G3: Optional[int] = None
    model_config = ConfigDict(from_attributes=True)

class PredictionRequest(BaseModel):
    prediction_mode: str = Field("performance", description="'early_warning' or 'performance'")
    student_id: Optional[int] = None
    features: StudentBase

class FeatureContribution(BaseModel):
    feature: str
    importance: float
    direction: str

class EarlyWarningSignal(BaseModel):
    code: str
    severity: str
    message: str

class Recommendation(BaseModel):
    area: str
    action: str
    impact: str

class PredictionResponse(BaseModel):
    prediction_mode: str
    predicted_score: float
    pass_probability: float
    risk_probability: float
    risk_score: float
    risk_category: str
    is_anomaly: bool
    anomaly_description: str
    top_positive_contributors: List[FeatureContribution]
    top_negative_contributors: List[FeatureContribution]
    early_warnings: List[EarlyWarningSignal]
    recommendations: List[Recommendation]

class SimulationRequest(BaseModel):
    prediction_mode: str = "performance"
    baseline_features: StudentBase
    modified_features: StudentBase

class SimulationResponse(BaseModel):
    baseline_predicted_score: float
    simulated_predicted_score: float
    score_delta: float
    baseline_risk_score: float
    simulated_risk_score: float
    risk_score_delta: float
    baseline_risk_category: str
    simulated_risk_category: str
    disclaimer: str

class CopilotRequest(BaseModel):
    query: str
    student_id: Optional[int] = None
    prediction_context: Optional[PredictionResponse] = None

class CopilotResponse(BaseModel):
    query: str
    answer: str
    grounded_context_used: bool

class DatasetValidationError(BaseModel):
    row_index: int
    column: str
    error_message: str

class CSVValidationResponse(BaseModel):
    filename: str
    total_rows: int
    valid_rows: int
    invalid_rows: int
    errors: List[DatasetValidationError]
    sample_preview: List[Dict[str, Any]]
