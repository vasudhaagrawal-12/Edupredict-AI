"""
SQLAlchemy ORM Database Models for EduPredict AI
"""

import datetime
from sqlalchemy import Column, Integer, Float, String, Boolean, DateTime, Text, ForeignKey, JSON
from sqlalchemy.orm import relationship
from backend.app.core.database import Base

class StudentDB(Base):
    __tablename__ = "students"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    school = Column(String(10), default="GP")
    sex = Column(String(2), default="F")
    age = Column(Integer, default=17)
    address = Column(String(2), default="U")
    famsize = Column(String(5), default="GT3")
    Pstatus = Column(String(2), default="T")
    Medu = Column(Integer, default=2)
    Fedu = Column(Integer, default=2)
    Mjob = Column(String(20), default="other")
    Fjob = Column(String(20), default="other")
    reason = Column(String(20), default="course")
    guardian = Column(String(20), default="mother")
    traveltime = Column(Integer, default=1)
    studytime = Column(Integer, default=2)
    failures = Column(Integer, default=0)
    schoolsup = Column(String(5), default="no")
    famsup = Column(String(5), default="yes")
    paid = Column(String(5), default="no")
    activities = Column(String(5), default="no")
    nursery = Column(String(5), default="yes")
    higher = Column(String(5), default="yes")
    internet = Column(String(5), default="yes")
    romantic = Column(String(5), default="no")
    famrel = Column(Integer, default=4)
    freetime = Column(Integer, default=3)
    goout = Column(Integer, default=3)
    Dalc = Column(Integer, default=1)
    Walc = Column(Integer, default=1)
    health = Column(Integer, default=4)
    absences = Column(Integer, default=4)
    G1 = Column(Integer, nullable=True)
    G2 = Column(Integer, nullable=True)
    G3 = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    predictions = relationship("PredictionDB", back_populates="student", cascade="all, delete-orphan")

class PredictionDB(Base):
    __tablename__ = "predictions"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    student_id = Column(Integer, ForeignKey("students.id"), nullable=True)
    prediction_mode = Column(String(30), default="performance")
    predicted_score = Column(Float, nullable=False)
    pass_probability = Column(Float, nullable=False)
    risk_probability = Column(Float, nullable=False)
    risk_score = Column(Float, nullable=False)
    risk_category = Column(String(20), nullable=False)
    is_anomaly = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    student = relationship("StudentDB", back_populates="predictions")
    explanation = relationship("ExplanationDB", back_populates="prediction", uselist=False, cascade="all, delete-orphan")

class ExplanationDB(Base):
    __tablename__ = "explanations"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    prediction_id = Column(Integer, ForeignKey("predictions.id"), nullable=False)
    top_positives = Column(JSON, nullable=True)
    top_negatives = Column(JSON, nullable=True)
    early_warnings = Column(JSON, nullable=True)
    recommendations = Column(JSON, nullable=True)

    prediction = relationship("PredictionDB", back_populates="explanation")

class DatasetUploadDB(Base):
    __tablename__ = "dataset_uploads"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    filename = Column(String(255), nullable=False)
    row_count = Column(Integer, default=0)
    valid_count = Column(Integer, default=0)
    error_count = Column(Integer, default=0)
    status = Column(String(50), default="SUCCESS")
    uploaded_at = Column(DateTime, default=datetime.datetime.utcnow)
