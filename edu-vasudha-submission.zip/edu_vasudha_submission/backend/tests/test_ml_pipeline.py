"""
Pytest ML Pipeline Test Suite for EduPredict AI
"""

import pytest
import numpy as np
import pandas as pd
from backend.app.schemas.contracts import StudentBase
from backend.app.ml.inference_engine import inference_engine
from ml.features.engineer import engineer_features
from ml.preprocessing.pipeline import build_preprocessor

def test_feature_engineering_early_warning_drops_g1_g2():
    df = pd.DataFrame([{
        "school": "GP", "sex": "F", "age": 17, "failures": 1, "Dalc": 2, "Walc": 3,
        "Medu": 3, "Fedu": 3, "famrel": 4, "G1": 12, "G2": 10
    }])
    df_engineered = engineer_features(df, mode="early_warning")
    
    assert "past_failures_flag" in df_engineered.columns
    assert df_engineered["past_failures_flag"].iloc[0] == 1
    assert "alcohol_consumption_index" in df_engineered.columns
    assert df_engineered["alcohol_consumption_index"].iloc[0] == 5
    assert "G1" not in df_engineered.columns
    assert "G2" not in df_engineered.columns
    assert "assessment_trend" not in df_engineered.columns

def test_feature_engineering_performance_includes_trend():
    df = pd.DataFrame([{
        "school": "GP", "sex": "F", "age": 17, "failures": 0, "Dalc": 1, "Walc": 1,
        "Medu": 4, "Fedu": 4, "famrel": 5, "G1": 10, "G2": 14
    }])
    df_engineered = engineer_features(df, mode="performance")
    
    assert "assessment_trend" in df_engineered.columns
    assert df_engineered["assessment_trend"].iloc[0] == 4

def test_preprocessor_transformation_shape():
    df = pd.DataFrame([{
        "school": "GP", "sex": "F", "age": 17, "address": "U", "famsize": "GT3", "Pstatus": "T",
        "Medu": 2, "Fedu": 2, "Mjob": "other", "Fjob": "other", "reason": "course", "guardian": "mother",
        "traveltime": 1, "studytime": 2, "failures": 0, "schoolsup": "no", "famsup": "yes", "paid": "no",
        "activities": "no", "nursery": "yes", "higher": "yes", "internet": "yes", "romantic": "no",
        "famrel": 4, "freetime": 3, "goout": 3, "Dalc": 1, "Walc": 1, "health": 4, "absences": 4,
        "alcohol_consumption_index": 2, "family_support_score": 2.8, "G1": 10, "G2": 12, "assessment_trend": 2
    }])
    preproc = build_preprocessor(mode="performance")
    transformed = preproc.fit_transform(df)
    assert transformed.shape[0] == 1
    assert transformed.shape[1] > 10

def test_inference_engine_output_ranges():
    student = StudentBase(
        age=17, studytime=3, failures=0, absences=2, G1=14, G2=15
    )
    res = inference_engine.predict(student, mode="performance")
    
    assert 0.0 <= res.predicted_score <= 100.0
    assert 0.0 <= res.pass_probability <= 1.0
    assert 0.0 <= res.risk_probability <= 1.0
    assert 0.0 <= res.risk_score <= 100.0
    assert res.risk_category in ["LOW", "MODERATE", "HIGH", "CRITICAL"]
    assert isinstance(res.is_anomaly, bool)
