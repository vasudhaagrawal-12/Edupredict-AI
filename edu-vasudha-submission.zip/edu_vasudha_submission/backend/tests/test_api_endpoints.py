"""
Pytest API Endpoints Test Suite for EduPredict AI
"""

from fastapi.testclient import TestClient
from backend.app.main import app

client = TestClient(app)

def test_health_check_endpoint():
    response = client.get("/api/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert "models_loaded" in data

def test_predictions_endpoint():
    payload = {
        "prediction_mode": "performance",
        "features": {
            "school": "GP", "sex": "F", "age": 17, "address": "U", "famsize": "GT3", "Pstatus": "T",
            "Medu": 2, "Fedu": 2, "Mjob": "other", "Fjob": "other", "reason": "course", "guardian": "mother",
            "traveltime": 1, "studytime": 2, "failures": 0, "schoolsup": "no", "famsup": "yes", "paid": "no",
            "activities": "no", "nursery": "yes", "higher": "yes", "internet": "yes", "romantic": "no",
            "famrel": 4, "freetime": 3, "goout": 3, "Dalc": 1, "Walc": 1, "health": 4, "absences": 4,
            "G1": 12, "G2": 14
        }
    }
    response = client.post("/api/predictions", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "predicted_score" in data
    assert "risk_score" in data
    assert "risk_category" in data

def test_students_list_endpoint():
    response = client.get("/api/students")
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    assert len(data) > 0

def test_simulations_endpoint():
    payload = {
        "prediction_mode": "performance",
        "baseline_features": {
            "age": 17, "studytime": 1, "failures": 1, "absences": 12, "G1": 8, "G2": 8
        },
        "modified_features": {
            "age": 17, "studytime": 3, "failures": 1, "absences": 2, "G1": 8, "G2": 8
        }
    }
    response = client.post("/api/simulations", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "score_delta" in data
    assert "risk_score_delta" in data
    assert "disclaimer" in data

def test_models_endpoint():
    response = client.get("/api/models")
    assert response.status_code == 200
    data = response.json()
    assert "regression" in data
    assert "classification" in data
