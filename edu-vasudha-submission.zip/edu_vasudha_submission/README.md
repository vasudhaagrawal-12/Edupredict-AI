# EduPredict AI — Intelligent Student Performance Prediction & Early Warning System

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.109+-009688.svg)](https://fastapi.tiangolo.com/)
[![React](https://img.shields.io/badge/React-18-61DAFB.svg)](https://reactjs.org/)
[![Scikit-Learn](https://img.shields.io/badge/Scikit--Learn-1.4+-F7931E.svg)](https://scikit-learn.org/)
[![Playwright](https://img.shields.io/badge/Playwright-E2E-green.svg)](https://playwright.dev/)

EduPredict AI is a production-grade, full-stack machine learning platform for student academic performance prediction, failure risk classification, early-warning detection, explainable AI (SHAP), non-causal what-if simulations, grounded AI Copilot assistance, and analytical dashboards for educators.

---

## 🌟 Key Features

1. **Dual Prediction Tasks**:
   - **Regression**: Predicts exact final academic mark ($0.0 \dots 100.0$).
   - **Classification**: Predicts academic failure risk probability ($P(\text{Risk})$).
2. **Dual Prediction Modes**:
   - **Early-Warning Mode (Pre-Assessment)**: Uses baseline demographics, study habits, absences, and prior failures available before term exams.
   - **Performance-Prediction Mode (Assessment-Integrated)**: Incorporates term assessment scores ($G1, G2$) for mid-cycle risk evaluation.
3. **Explainable AI (SHAP)**:
   - Uses `TreeExplainer` for tree models and `LinearExplainer` for linear models to show local positive and negative feature attributions.
4. **Calibrated Risk Engine & Thresholds**:
   - Grounded in calibrated classification probability $P(\text{Risk}) \times 100$.
   - Centralized risk categories: `LOW` (<25), `MODERATE` (25–49), `HIGH` (50–74), `CRITICAL` ($\ge 75$).
5. **Interactive What-If Simulator**:
   - Allows educators to change study time, absences, or G1/G2 scores and observe simulated model response deltas.
6. **Grounded AI Copilot**:
   - Grounded strictly in actual predictions, SHAP feature attributions, and risk indicators with a deterministic fallback engine.
7. **Model Lab & Model Selection**:
   - Evaluates 5 Regression and 4 Classification algorithms on held-out test data.
8. **Batch CSV Upload & Validation**:
   - Drag-and-drop CSV validator with row-level error reports.

---

## 🏗️ Repository Architecture

```
edupredict-ai/
├── frontend/                     # React 18 + TypeScript + Vite + Tailwind CSS + Recharts
│   ├── src/
│   │   ├── components/           # Reusable UI components (MetricCard, RiskBadge, SHAPChart, etc.)
│   │   ├── pages/                # Landing, Dashboard, StudentProfile, ModelLab, CSVUpload, Copilot
│   │   ├── services/             # Typed API client
│   │   ├── types/                # TypeScript interfaces matching backend Pydantic schemas
│   │   └── utils/                # Design tokens & formatters
│   ├── tests/e2e/                # Playwright E2E tests
│   ├── playwright.config.ts
│   ├── package.json
│   └── vite.config.ts
├── backend/                      # Python FastAPI REST API
│   ├── app/
│   │   ├── api/                  # Thin FastAPI route handlers
│   │   ├── core/                 # App configuration & database setup
│   │   ├── models/               # SQLAlchemy ORM schemas
│   │   ├── schemas/              # Pydantic v2 data contracts
│   │   ├── repositories/         # Database access layer
│   │   ├── services/             # Risk engine, recommendations, copilot service
│   │   ├── ml/                   # Production inference loader & anomaly detector
│   │   └── main.py               # FastAPI entry point
│   ├── tests/                    # Pytest suite (unit, API, database, ML)
│   └── requirements.txt
├── ml/                           # Machine Learning Pipeline
│   ├── preprocessing/            # Sklearn ColumnTransformer & scaling pipeline
│   ├── features/                 # Derived feature engineering transformers
│   ├── training/                 # Model trainers (5 Regressors, 4 Classifiers)
│   ├── evaluation/               # Metric evaluators
│   ├── explainability/           # SHAP TreeExplainer / LinearExplainer wrappers
│   ├── anomaly/                  # IsolationForest anomaly detector
│   └── artifacts/                # Persisted model binaries & real metrics
├── data/
│   ├── raw/                      # Downloaded UCI student dataset (student-mat.csv)
│   ├── processed/                # Preprocessed train/test split & EDA JSON
│   └── sample_students.csv       # Sample batch CSV for validation testing
├── scripts/                      # Automation scripts (download_dataset.py, train_pipeline.py, seed_db.py)
├── docs/                         # Mandatory technical documentation
│   ├── architecture.md
│   ├── ml_methodology.md
│   ├── feature_registry.md
│   ├── leakage_audit.md
│   ├── api.md
│   ├── viva_questions.md
│   └── ethics.md
├── docker-compose.yml
├── Dockerfile.backend
├── Dockerfile.frontend
├── .env.example
├── .gitignore
├── README.md
└── LICENSE
```

---

## 📊 Real Model Evaluation Results

### Regression Models Evaluated (5 Candidates)
| Model Candidate | MAE | RMSE | R² Score | Status |
| :--- | :---: | :---: | :---: | :---: |
| **Random Forest Regressor** | **6.2342** | **7.8601** | **0.7382** | **Selected** |
| Gradient Boosting Regressor | 6.2557 | 7.8916 | 0.7361 | Candidate |
| Ridge Regression | 6.4554 | 7.9079 | 0.7350 | Candidate |
| Linear Regression | 6.4699 | 7.9181 | 0.7344 | Candidate |
| XGBoost Regressor | 7.1214 | 8.7366 | 0.6766 | Candidate |

### Classification Models Evaluated (4 Candidates)
| Model Candidate | Accuracy | Precision | Recall | F1 Score | ROC-AUC | Status |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **Logistic Regression** | **88.61%** | **0.9091** | **0.8333** | **0.8696** | **0.9490** | **Selected** |
| Random Forest Classifier | 88.61% | 0.9091 | 0.8333 | 0.8696 | 0.9496 | Candidate |
| Gradient Boosting Classifier | 87.34% | 0.8966 | 0.8056 | 0.8485 | 0.9335 | Candidate |
| XGBoost Classifier | 86.08% | 0.8889 | 0.7889 | 0.8358 | 0.9432 | Candidate |

*Evaluated on 20% held-out test split ($N=79$). All metrics generated from actual training execution.*

---

## 🚀 Quick Start & Installation

### 1. Prerequisites
- Python 3.11+
- Node.js v18+ & npm

### 2. Backend Setup
```bash
# Install Python dependencies
pip install -r backend/requirements.txt

# Download UCI dataset
python scripts/download_dataset.py

# Train ML models & generate artifacts
python -m ml.training.trainer

# Seed local database
python -m scripts.seed_db

# Start FastAPI backend
python -m backend.app.main
```
Backend API will run at `http://localhost:8000`. OpenAPI docs at `http://localhost:8000/docs`.

### 3. Frontend Setup
```bash
cd frontend

# Install Node dependencies
npm install

# Start Vite dev server
npm run dev
```
Frontend web application will run at `http://localhost:5173`.

---

## 🧪 Testing Infrastructure

### Backend Pytest Suite
```bash
python -m pytest backend/tests
```
Runs 9 comprehensive unit, API contract, database, and ML inference range tests.

### Playwright E2E Browser Testing
```bash
cd frontend
npm run test:e2e
```
Runs Playwright automated end-to-end browser tests verifying user flow from Landing Page $\to$ Dashboard $\to$ Student Selection $\to$ Prediction Form $\to$ SHAP render $\to$ Simulator $\to$ CSV Upload.

---

## 🐳 Docker Setup

Run the full containerized stack using Docker Compose:
```bash
docker-compose up --build
```
- Frontend: `http://localhost`
- Backend API: `http://localhost:8000`

---

## 📜 Ethical Considerations & Limitations

1. **Advisory Decision Support**: EduPredict AI outputs are probabilistic statistical indicators intended to assist educators. They must **never** be used for automated disciplinary or punitive actions.
2. **Non-Causal Simulations**: What-If scenario simulations display model response behavior and do not prove causal real-world intervention outcomes.
3. **Data Privacy**: Protected demographic attributes are excluded from model features.

---

## 📄 License
Distributed under the MIT License. See [LICENSE](LICENSE) for details.
