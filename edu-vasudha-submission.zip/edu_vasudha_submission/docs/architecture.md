# System Architecture - EduPredict AI

EduPredict AI is designed as a modular, decoupled full-stack machine learning application comprising a React 18 single-page frontend, a Python FastAPI REST API, a Scikit-Learn / XGBoost / SHAP machine learning engine, and an SQLAlchemy database layer.

---

## 1. High-Level Architecture Diagram

```
                       ┌────────────────────────────────────────┐
                       │          React 18 + TS Frontend        │
                       │ (Vite + Tailwind CSS + Recharts + XAI) │
                       └───────────────────┬────────────────────┘
                                           │ HTTP / JSON REST APIs
                                           ▼
                       ┌────────────────────────────────────────┐
                       │            FastAPI Backend             │
                       │    (API Routes + Services + Schemas)   │
                       └─────────┬───────────────────┬──────────┘
                                 │                   │
                     ORM Queries │                   │ Inference Requests
                                 ▼                   ▼
                     ┌──────────────────┐    ┌───────────────────────────┐
                     │   SQLAlchemy DB  │    │     ML Inference Engine   │
                     │ (SQLite / Postgres)   │ (Preprocessors + Models)  │
                     └──────────────────┘    └─────────────┬─────────────┘
                                                           │
                                                           ▼
                                                     ┌───────────┐
                                                     │ SHAP & XAI│
                                                     └───────────┘
```

---

## 2. Component Responsibilities

### Frontend Layer (`frontend/`)
- **React 18 + Vite + TypeScript**: Single-page user interface with strict typed contracts.
- **State & Service Layer (`services/api.ts`)**: Centralized typed client delegating API communication.
- **Design System (`utils/theme.ts`)**: Coherent glassmorphism dark theme, centralized risk badge color mappings.

### Backend Layer (`backend/app/`)
- **API Routers (`api/routes.py`)**: Thin endpoint handlers validating incoming Pydantic schemas.
- **Business Services (`services/`)**: Centralized risk score calculation engine, early warning signal evaluation, and grounded AI Copilot fallback.
- **Database Layer (`models/orm.py`, `repositories/`)**: SQLAlchemy ORM storing students, predictions, explanations, and CSV upload logs.

### ML & Explainability Layer (`ml/`)
- **Preprocessing Pipeline (`ml/preprocessing/`)**: Leakage-free `ColumnTransformer` with imputers, scalers, and encoders.
- **Feature Engineering (`ml/features/`)**: Derived feature transformers for `past_failures_flag`, `alcohol_consumption_index`, `family_support_score`, and `assessment_trend`.
- **Model Artifacts (`ml/artifacts/`)**: Persisted model binaries (`model.joblib`), evaluation metrics (`metrics.json`), and model metadata (`metadata.json`).
- **Explainability (`ml/explainability/`)**: `shap.TreeExplainer` and `shap.LinearExplainer` wrappers.

---

## 3. Data Flow Workflow

1. **User Request**: User fills student feature parameters on frontend UI or selects cohort student.
2. **Validation**: Frontend transmits request payload to `POST /api/predictions`. FastAPI validates against `PredictionRequest` Pydantic schema.
3. **ML Inference**: `MLInferenceEngine` transforms inputs using persisted preprocessing pipeline, calculates regression score and calibrated classification risk probability.
4. **XAI Attribution**: `TreeExplainer` or `LinearExplainer` computes local SHAP feature importances.
5. **Risk Engine**: `risk_engine` derives risk score ($0-100$), maps risk category (`LOW`, `MODERATE`, `HIGH`, `CRITICAL`), and generates grounded recommendations.
6. **Response & Persistence**: Response returned to UI and logged into SQLAlchemy database.
