# Feature Registry - EduPredict AI

This document establishes the authoritative data feature definitions, prediction mode availability, mathematical calculations, and academic rationale for all variables used across the EduPredict AI machine learning system.

---

## 1. Targets & Identifiers

| Field Name | Type | Range / Values | Description | Role |
| :--- | :--- | :--- | :--- | :--- |
| `student_id` | Integer | $1 \dots N$ | Unique student record key | Identifier |
| `G3` | Integer | $0 \dots 20$ | Raw final exam mark | Raw Target |
| `final_marks` | Float | $0.0 \dots 100.0$ | Rescaled final mark ($G3 \times 5$) | **Regression Target** |
| `at_risk` | Binary | $0$ (Pass), $1$ (Risk) | Student failure indicator ($G3 < 10$, i.e. $<50\%$) | **Classification Target** |

---

## 2. Prediction Modes & Feature Availability

EduPredict AI enforces strict control flow based on prediction timing to prevent target leakage:

### Mode A: Early-Warning Mode (Pre-Assessment)
- **Prediction Timing**: At student enrollment or start of academic term.
- **Available Data**: Demographics, parental education, study time, prior class failures, absences, alcohol consumption, and extracurricular activities.
- **Excluded Features**: $G1, G2, G3, final\_marks, at\_risk$.

### Mode B: Performance-Prediction Mode (Assessment-Integrated)
- **Prediction Timing**: Mid-term (after $G1$ and/or $G2$ grades are recorded).
- **Available Data**: All Early-Warning features + Period assessment marks ($G1, G2$) and assessment progression trend ($G2 - G1$).
- **Excluded Features**: $G3, final\_marks, at\_risk$.

---

## 3. Raw Feature Definitions

| Feature Name | Mode A | Mode B | Category | Type | Valid Range | Description |
| :--- | :---: | :---: | :--- | :--- | :--- | :--- |
| `age` | Yes | Yes | Demographic | Numeric | $15 \dots 22$ | Student age in years |
| `sex` | Yes | Yes | Demographic | Categorical | `F`, `M` | Student gender |
| `address` | Yes | Yes | Environmental | Categorical | `U` (Urban), `R` (Rural) | Home address type |
| `famsize` | Yes | Yes | Family | Categorical | `GT3` (>3), `LE3` ($\le 3$) | Family size |
| `Pstatus` | Yes | Yes | Family | Categorical | `T` (Together), `A` (Apart) | Parental cohabitation status |
| `Medu` | Yes | Yes | Family | Numeric | $0 \dots 4$ | Mother's education level |
| `Fedu` | Yes | Yes | Family | Numeric | $0 \dots 4$ | Father's education level |
| `Mjob` | Yes | Yes | Family | Categorical | `teacher`, `health`, `services`, `at_home`, `other` | Mother's job |
| `Fjob` | Yes | Yes | Family | Categorical | `teacher`, `health`, `services`, `at_home`, `other` | Father's job |
| `reason` | Yes | Yes | Motivation | Categorical | `home`, `reputation`, `course`, `other` | Reason to choose school |
| `guardian` | Yes | Yes | Family | Categorical | `mother`, `father`, `other` | Student's guardian |
| `traveltime` | Yes | Yes | Lifestyle | Numeric | $1 \dots 4$ | Travel time to school ($1: <15$m, $4: >1$h) |
| `studytime` | Yes | Yes | Academic | Numeric | $1 \dots 4$ | Weekly study hours ($1: <2$h, $4: >10$h) |
| `failures` | Yes | Yes | History | Numeric | $0 \dots 4$ | Past class failures ($0 \dots 3$, $4: \ge 4$) |
| `schoolsup` | Yes | Yes | Support | Categorical | `yes`, `no` | Extra educational support |
| `famsup` | Yes | Yes | Support | Categorical | `yes`, `no` | Family educational support |
| `paid` | Yes | Yes | Support | Categorical | `yes`, `no` | Extra paid classes |
| `activities` | Yes | Yes | Engagement | Categorical | `yes`, `no` | Extra-curricular activities |
| `nursery` | Yes | Yes | Background | Categorical | `yes`, `no` | Attended nursery school |
| `higher` | Yes | Yes | Motivation | Categorical | `yes`, `no` | Wants higher education |
| `internet` | Yes | Yes | Resource | Categorical | `yes`, `no` | Internet access at home |
| `romantic` | Yes | Yes | Lifestyle | Categorical | `yes`, `no` | With a romantic relationship |
| `famrel` | Yes | Yes | Family | Numeric | $1 \dots 5$ | Quality of family relationships |
| `freetime` | Yes | Yes | Lifestyle | Numeric | $1 \dots 5$ | Free time after school |
| `goout` | Yes | Yes | Social | Numeric | $1 \dots 5$ | Going out with friends |
| `Dalc` | Yes | Yes | Lifestyle | Numeric | $1 \dots 5$ | Workday alcohol consumption |
| `Walc` | Yes | Yes | Lifestyle | Numeric | $1 \dots 5$ | Weekend alcohol consumption |
| `health` | Yes | Yes | Well-being | Numeric | $1 \dots 5$ | Current health status |
| `absences` | Yes | Yes | Attendance | Numeric | $0 \dots 93$ | Number of school absences |
| `G1` | No | Yes | Assessment | Numeric | $0 \dots 20$ | First period grade |
| `G2` | No | Yes | Assessment | Numeric | $0 \dots 20$ | Second period grade |

---

## 4. Engineed Feature Registry

All engineered features have explicit mathematical definitions and academic justifications:

### 1. `past_failures_flag`
- **Mode Availability**: Mode A & Mode B
- **Source Columns**: `failures`
- **Calculation**: $\mathbb{I}(\text{failures} > 0)$
- **Academic Rationale**: Prior academic failure is a strong psychological and foundational predictor of future academic vulnerability. Converting to a binary indicator highlights vulnerability.

### 2. `alcohol_consumption_index`
- **Mode Availability**: Mode A & Mode B
- **Source Columns**: `Dalc`, `Walc`
- **Calculation**: $\text{Dalc} + \text{Walc}$ (Range $2 \dots 10$)
- **Academic Rationale**: Combined workday and weekend alcohol consumption reflects lifestyle factors that directly affect sleep, cognitive focus, and attendance.

### 3. `family_support_score`
- **Mode Availability**: Mode A & Mode B
- **Source Columns**: `Medu`, `Fedu`, `famrel`
- **Calculation**: $\frac{\text{Medu} + \text{Fedu}}{2} + \frac{\text{famrel}}{5}$ (Range $0 \dots 5$)
- **Academic Rationale**: Combines parental educational capital with emotional family stability to capture home support quality.

### 4. `assessment_trend`
- **Mode Availability**: **Mode B Only**
- **Source Columns**: `G1`, `G2`
- **Calculation**: $G2 - G1$ (Range $-20 \dots +20$)
- **Academic Rationale**: Measures immediate trajectory over the term. A negative delta indicates declining performance requiring early warning intervention.
