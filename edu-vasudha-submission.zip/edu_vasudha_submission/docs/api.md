# REST API Documentation - EduPredict AI

This document specifies the REST API endpoints, request contracts, and response schemas provided by the EduPredict AI backend.

---

## Base URL
- Local Development: `http://localhost:8000/api`
- Interactive OpenAPI Docs: `http://localhost:8000/docs`

---

## Endpoints Overview

### 1. Health Check
`GET /api/health`

**Response Example (200 OK)**:
```json
{
  "status": "healthy",
  "service": "EduPredict AI",
  "version": "1.0.0",
  "models_loaded": ["regression", "classification"]
}
```

---

### 2. Single Student Prediction & SHAP Explanation
`POST /api/predictions`

**Request Body**:
```json
{
  "prediction_mode": "performance",
  "features": {
    "age": 17,
    "studytime": 2,
    "failures": 0,
    "absences": 4,
    "G1": 12,
    "G2": 14
  }
}
```

**Response Example (200 OK)**:
```json
{
  "prediction_mode": "performance",
  "predicted_score": 68.5,
  "pass_probability": 0.88,
  "risk_probability": 0.12,
  "risk_score": 12.0,
  "risk_category": "LOW",
  "is_anomaly": false,
  "anomaly_description": "Normal pattern",
  "top_positive_contributors": [
    {"feature": "studytime", "importance": 0.45, "direction": "positive"}
  ],
  "top_negative_contributors": [
    {"feature": "absences", "importance": -0.25, "direction": "negative"}
  ],
  "early_warnings": [],
  "recommendations": [
    {
      "area": "Study Habit",
      "action": "Maintain study consistency.",
      "impact": "Positive"
    }
  ]
}
```

---

### 3. Interactive What-If Scenario Simulation
`POST /api/simulations`

**Request Body**:
```json
{
  "prediction_mode": "performance",
  "baseline_features": {"studytime": 1, "absences": 12, "G1": 8, "G2": 8},
  "modified_features": {"studytime": 3, "absences": 2, "G1": 8, "G2": 8}
}
```

---

### 4. CSV Schema Validation
`POST /api/datasets/validate` (Multipart Form Data with `.csv` file)

---

### 5. Model Lab Metadata & Metrics
`GET /api/models`

Returns real evaluation metrics for 5 regression candidates and 4 classification candidates.

---

### 6. Grounded AI Copilot Query
`POST /api/copilot`

**Request Body**:
```json
{
  "query": "Why is this student at risk?",
  "prediction_context": { ... }
}
```
