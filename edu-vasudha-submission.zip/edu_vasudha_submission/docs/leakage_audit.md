# Data Leakage Audit & Prevention Report - EduPredict AI

This audit formally documents the methodology used in EduPredict AI to eliminate data leakage across feature engineering, preprocessing pipelines, model cross-validation, and production inference.

---

## 1. Target Variables & Exclusion Boundary

- **Regression Target**: `final_marks` (scaled from $G3 \times 5$, range $0 \dots 100$).
- **Classification Target**: `at_risk` (binary, $1$ if $G3 < 10$, $0$ otherwise).

### Explicit Leakage Prevention Rules:
1. **Target Exclusion**: Neither `G3`, `final_marks`, nor `at_risk` are ever passed into the feature matrix $X$ during training or inference.
2. **Mode-Specific Feature Availability**:
   - **Early-Warning Mode**: $G1$ and $G2$ period assessment marks are strictly removed prior to preprocessing and training.
   - **Performance-Prediction Mode**: $G1$ and $G2$ period assessment marks are included as valid historical predictor features available mid-term.
3. **Train/Test Pipeline Isolation**:
   - All statistical imputers (`SimpleImputer`), standard scalers (`StandardScaler`), and categorical encoders (`OneHotEncoder`) are fit **only** on the training split ($X_{\text{train}}$).
   - Validation and test splits ($X_{\text{test}}$) are transformed using pre-fit transformers without re-fitting.

---

## 2. Feature Boundary Verification

| Feature | Category | Included in Early-Warning ($X$) | Included in Performance ($X$) | Target Leakage Risk | Mitigation Strategy |
| :--- | :--- | :---: | :---: | :--- | :--- |
| `G3` | Raw Final Grade | **No** | **No** | Critical | Stripped at dataset load |
| `final_marks` | Target | **No** | **No** | Critical | Derived target only |
| `at_risk` | Target | **No** | **No** | Critical | Derived target only |
| `G1` | First Period Mark | **No** | **Yes** | High (if Early-Warning) | Stripped in Early-Warning Mode |
| `G2` | Second Period Mark | **No** | **Yes** | High (if Early-Warning) | Stripped in Early-Warning Mode |
| `assessment_trend` | Delta ($G2 - G1$) | **No** | **Yes** | High (if Early-Warning) | Calculated only in Mode B |
| `failures` | Historical Failures | **Yes** | **Yes** | None | Past term information |
| `absences` | Term Absences | **Yes** | **Yes** | None | Real-time tracking data |

---

## 3. Audit Sign-Off

- [x] Preprocessing fit strictly on $X_{\text{train}}$
- [x] No target variable or derived target in input feature space
- [x] Early-Warning mode verified zero presence of $G1 / G2 / G3$
- [x] Cross-validation splits pre-transform fitted
