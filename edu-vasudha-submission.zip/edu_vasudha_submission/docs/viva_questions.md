# University Viva & Technical Defense Guide - EduPredict AI

This guide contains key technical questions and answers designed for academic reviews, portfolio interviews, and technical viva defenses of the EduPredict AI system.

---

## 1. Machine Learning & Modeling

### Q1: How did you select the regression and classification targets?
**Answer**:
- **Regression**: We predict the student's continuous final mark `final_marks`, rescaled from raw UCI grade $G3$ ($G3 \times 5$, range $0-100$).
- **Classification**: We predict failure risk `at_risk` defined as $G3 < 10$ ($<50\%$), representing academic failure. Both targets strictly originate from the ground-truth dataset.

### Q2: How did you prevent target data leakage?
**Answer**:
Target variables ($G3, final\_marks, at\_risk$) are strictly excluded from input features $X$. Preprocessing pipeline transformers (`SimpleImputer`, `StandardScaler`, `OneHotEncoder`) are fit strictly on the 80% training split. For Early-Warning Mode, term assessment marks ($G1, G2$) are stripped prior to model fitting.

### Q3: What models were evaluated in Model Lab?
**Answer**:
- **5 Regression Candidates**: Linear Regression, Ridge Regression, Random Forest Regressor, Gradient Boosting Regressor, XGBoost Regressor.
- **4 Classification Candidates**: Logistic Regression, Random Forest Classifier, Gradient Boosting Classifier, XGBoost Classifier.
Selected best models: Random Forest Regressor (MAE 6.23) and Logistic Regression (Accuracy 88.61%, ROC-AUC 0.9490).

---

## 2. Explainability & Risk Scoring

### Q4: How does SHAP explain individual student predictions?
**Answer**:
We use `shap.TreeExplainer` for tree models and `shap.LinearExplainer` for linear models. SHAP values calculate the additive feature attribution of each feature relative to the base expected value, highlighting the top positive and negative drivers for a specific prediction.

### Q5: How is the academic risk score derived?
**Answer**:
The risk score baseline is calibrated probability $P(\text{Risk}) \times 100$. Classification models are probability-calibrated using `CalibratedClassifierCV(cv=3)`. Thresholds map scores to `LOW` (<25), `MODERATE` (25-49), `HIGH` (50-74), and `CRITICAL` ($\ge 75$).

---

## 3. Architecture & Software Engineering

### Q6: How is the codebase structured for production reproducibility?
**Answer**:
The codebase follows clean separation of concerns: React 18 + TypeScript frontend, FastAPI backend with Pydantic v2 schemas and SQLAlchemy repository pattern, persisted joblib ML models, Pytest unit/API tests, Playwright E2E browser tests, and Docker container orchestration (`docker-compose.yml`).
