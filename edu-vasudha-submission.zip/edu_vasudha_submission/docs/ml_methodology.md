# Machine Learning Methodology - EduPredict AI

This document provides a comprehensive technical overview of the machine learning architecture, training methodology, evaluation metrics, probability calibration, risk score calculation, and explainability system implemented in EduPredict AI.

---

## 1. Dual Prediction Tasks

EduPredict AI formulates student academic performance evaluation into two complementary ML objectives:

### A. Regression Task
- **Objective**: Predict a student's final academic mark on a continuous scale ($0.0 \dots 100.0$).
- **Target Variable**: `final_marks = G3 * 5`
- **Evaluation Metrics**: Mean Absolute Error (MAE), Root Mean Squared Error (RMSE), and Coefficient of Determination ($R^2$).

### B. Classification Task
- **Objective**: Predict the probability of academic failure/risk ($P(\text{Risk})$).
- **Target Variable**: `at_risk = (G3 < 10)` (Score $<50\%$).
- **Evaluation Metrics**: Accuracy, Precision, Recall, F1 Score, ROC-AUC, PR-AUC, and Brier Score.

---

## 2. Model Candidates Evaluated

### Regression Candidates (5)
1. **Linear Regression**: Baseline interpretable linear model.
2. **Ridge Regression**: $L_2$-regularized linear model.
3. **Random Forest Regressor**: Non-linear ensemble of decision trees.
4. **Gradient Boosting Regressor**: Sequential boosting ensemble.
5. **XGBoost Regressor**: Optimized gradient boosted decision tree algorithm.

### Classification Candidates (4)
1. **Logistic Regression**: Regularized linear classifier.
2. **Random Forest Classifier**: Ensemble of decision trees.
3. **Gradient Boosting Classifier**: Sequential boosted classifier.
4. **XGBoost Classifier**: Extreme gradient boosted decision tree classifier.

---

## 3. Training & Validation Strategy

- **Train/Test Split**: Stratified 80% train split ($N=316$), 20% held-out test split ($N=79$).
- **Cross-Validation**: 5-fold Stratified Cross-Validation on the training split for hyperparameter tuning.
- **Probability Calibration**: Classifiers are calibrated using `CalibratedClassifierCV(cv=3)` to ensure predicted probabilities match empirical real-world frequencies.
- **Test Set Isolation**: The test set is held out completely and evaluated only once after model selection to prevent test-set leakage.

---

## 4. Model Selection Results (Real Execution Metrics)

### Selected Regression Model: **Random Forest Regressor**
- **MAE**: 6.2342
- **RMSE**: 7.8601
- **$R^2$ Score**: 0.7382

### Selected Classification Model: **Logistic Regression**
- **Accuracy**: 88.61%
- **F1 Score**: 0.8696
- **ROC-AUC**: 0.9490
- **Brier Score**: 0.0970

---

## 5. Risk Score Methodology

- **Baseline Methodology**: Calibrated probability $P(\text{Risk}) \times 100$.
- **Validation Rationale**: Calibrated classification probability provides optimal probabilistic risk calibration without double-counting collinear signals.
- **Threshold Mapping**:
  - `LOW RISK`: Score $< 25$
  - `MODERATE RISK`: $25 \le \text{Score} < 50$
  - `HIGH RISK`: $50 \le \text{Score} < 75$
  - `CRITICAL RISK`: Score $\ge 75$

---

## 6. Explainable AI (SHAP)

- **Tree-based Models**: Evaluated via `shap.TreeExplainer`.
- **Linear Models**: Evaluated via `shap.LinearExplainer`.
- Local feature attributions decompose the model's output score into additive contributions per feature, identifying top positive and negative drivers.
